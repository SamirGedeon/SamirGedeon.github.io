/** Read-only portfolio handler; assets and policies are inserted by the build. */
export function createPortfolioWorker(assets, policies) {
  const decoded = new Map();
  function reply(body, status, extras = {}) {
    return new Response(body, { status, headers: { ...policies, ...extras } });
  }
  return {
    fetch(request) {
      if (!['GET', 'HEAD'].includes(request.method)) return reply(null,405,{Allow:'GET, HEAD'});
      let path;
      try { path = decodeURIComponent(new URL(request.url).pathname); } catch { return reply('Not found',404,{'Content-Type':'text/plain; charset=utf-8'}); }
      if (path === '/') path = '/index.html';
      if (!Object.hasOwn(assets,path)) return reply('Not found',404,{'Content-Type':'text/plain; charset=utf-8'});
      const asset = assets[path];
      const headers = { 'Content-Type':asset.type, 'Content-Length':String(asset.size), ETag:asset.etag, 'Cache-Control':'public, max-age=0, must-revalidate' };
      if (request.headers.get('If-None-Match') === asset.etag) return reply(null,304,headers);
      if (request.method === 'HEAD') return reply(null,200,headers);
      if (!decoded.has(path)) {
        const binary = atob(asset.data), bytes = new Uint8Array(binary.length);
        for (let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
        decoded.set(path,bytes);
      }
      return reply(decoded.get(path),200,headers);
    }
  };
}
