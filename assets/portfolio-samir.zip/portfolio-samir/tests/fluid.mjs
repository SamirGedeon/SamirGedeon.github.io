/** GPU integration lifecycle tests with engine/observer stubs; no browser rendering. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';import vm from 'node:vm';
const source=readFileSync(new URL('../app.js',import.meta.url),'utf8');
const start=source.indexOf('function setupInkTrail() {'),end=source.indexOf('\n\nmotionListeners.push(setupInkTrail());',start);
assert.ok(start>=0&&end>start);const setup=source.slice(start,end);let passed=0;
function test(name,run){run();passed++;console.log('PASS',name)}
function fixture(options={}){
 let now=0,id=0,created=0,failed=false,prevented=false;
 const frames=new Map(),handlers=new Map(),canvasHandlers=new Map(),observers=[],calls=[];
 const flags={reduced:false,compact:false,lowPower:false,hidden:false,...options.flags};
 const bounds={left:30,top:50,right:1230,bottom:650,width:1200,height:600};
 const engine={};for(const name of ['setSize','splat','step','render','clear','destroy'])engine[name]=(...args)=>{calls.push({name,args});if(options.renderThrows&&name==='render')throw Error('lost GPU');return true};
 const factory=()=>{created++;return options.unsupported?null:engine};
 const canvas={hidden:true,addEventListener:(name,fn)=>canvasHandlers.set(name,fn)},hint={hidden:true};
 const section={getBoundingClientRect:()=>bounds,querySelectorAll:()=>[{getBoundingClientRect:()=>({left:230,top:150,width:300,height:100})}],addEventListener:(name,fn)=>handlers.set(name,fn)};
 const window=options.missingScript?{}:{SamirFluid:{create:factory}};
 const refresh=vm.runInNewContext(`(${setup})()`,{window,document:{querySelector:s=>s==='#ink-canvas'?canvas:s==='#contato'?section:hint},motionAllowed:()=>!Object.values(flags).some(Boolean),devicePixelRatio:2,performance:{now:()=>now},requestAnimationFrame(fn){const key=++id;frames.set(key,fn);return key},cancelAnimationFrame:key=>frames.delete(key),addEventListener(){},IntersectionObserver:class{constructor(fn){observers.push(fn)}observe(){}}});
 return {canvas,hint,flags,refresh,calls,get created(){return created},get pending(){return frames.size},get now(){return now},get prevented(){return prevented},
  move(x,y,advance=16,type='mouse'){now+=advance;handlers.get('pointermove')?.({pointerType:type,clientX:x+30,clientY:y+50})},
  frame(time=now+16){now=time;const queued=[...frames.values()];frames.clear();queued.forEach(fn=>fn(now))},
  offscreen(){observers.forEach(fn=>fn([{isIntersecting:false}]))},
  lose(){canvasHandlers.get('webglcontextlost')({preventDefault(){prevented=true}})},restore(){canvasHandlers.get('webglcontextrestored')()}
 };
}
const calls=(app,name)=>app.calls.filter(call=>call.name===name);
test('GPU initializes lazily, receives local input and renders premultiplied pigment with text masks',()=>{
 const app=fixture();assert.equal(app.created,0);assert.equal(app.pending,0);
 app.move(600,300);assert.equal(app.created,1);app.frame();
 assert.deepEqual(Array.from(calls(app,'setSize')[0].args),[1200,600,2]);
 const splat=calls(app,'splat')[0].args[0];assert.equal(splat.x,600);assert.equal(splat.y,300);
 assert.ok(splat.color.every(channel=>channel>=0&&channel<=.15));assert.equal(Math.max(...splat.color),.15);
 const render=calls(app,'render')[0].args[0];assert.equal(render.opacity,1);assert.equal(render.mask.length,1);assert.ok(render.mask[0].width>300);
 assert.ok(calls(app,'step')[0].args[0]<=1/60);
});
test('pointer events coalesce per frame and preserve real velocity instead of drawing colored bands',()=>{
 const app=fixture();app.move(100,100);app.frame();app.move(130,110);app.move(180,130);app.frame();
 const splat=calls(app,'splat').at(-1).args[0];assert.equal(splat.x,180);assert.equal(splat.dx,80);assert.equal(splat.dy,30);
 assert.equal(calls(app,'splat').length,2);
});
test('pigment remains active long enough to form vortices, fades, then stops all queued work',()=>{
 const app=fixture();app.move(500,250);app.frame();app.frame(1800);
 assert.equal(calls(app,'render').at(-1).args[0].opacity,1);assert.ok(app.pending>0);
 app.frame(6100);const opacity=calls(app,'render').at(-1).args[0].opacity;assert.ok(opacity>0&&opacity<1);
 app.frame(7200);assert.equal(app.pending,0);assert.equal(app.canvas.hidden,true);assert.ok(calls(app,'clear').length>0);
 const count=app.calls.length;app.frame(9000);assert.equal(app.calls.length,count);
});
test('stationary coordinates do not extend the animation lifetime',()=>{
 const app=fixture();app.move(500,250);app.frame();for(let i=0;i<5;i++)app.move(500,250,1000);
 app.frame(7200);assert.equal(app.pending,0);assert.equal(calls(app,'splat').length,1);
});
test('unavailable GPU or a missing engine leaves the contact readable and the canvas hidden',()=>{
 for(const options of [{unsupported:true},{missingScript:true}]){
  const app=fixture(options);app.move(500,250);app.frame();assert.equal(app.canvas.hidden,true);assert.equal(app.hint.hidden,true);assert.equal(app.pending,0);
 }
});
test('reduced, compact, low-power and background states never allocate GPU resources',()=>{
 for(const key of ['reduced','compact','lowPower','hidden']){
  const app=fixture({flags:{[key]:true}});app.move(500,250);app.frame();assert.equal(app.created,0,key);assert.equal(app.pending,0,key);assert.equal(app.canvas.hidden,true,key);
 }
 const touch=fixture();touch.move(500,250,16,'touch');touch.frame();assert.equal(touch.created,0);
});
test('leaving view or reducing movement clears the output and releases GPU resources',()=>{
 for(const disable of [app=>app.offscreen(),app=>{app.flags.reduced=true;app.refresh()}]){
  const app=fixture();app.move(500,250);app.frame();disable(app);assert.equal(app.pending,0);assert.equal(calls(app,'destroy').length,1);
 }
});
test('context loss and render failures fail gracefully, with recovery after context restoration',()=>{
 const app=fixture();app.move(500,250);app.frame();app.lose();assert.equal(app.prevented,true);assert.equal(app.pending,0);assert.equal(app.canvas.hidden,true);
 app.restore();app.move(600,250);app.frame();assert.equal(app.created,2);assert.equal(app.canvas.hidden,false);
 const broken=fixture({renderThrows:true});broken.move(500,250);assert.doesNotThrow(()=>broken.frame());assert.equal(broken.canvas.hidden,true);assert.equal(broken.pending,0);
});
console.log(`${passed} GPU integration lifecycle tests passed with stubs. Shaders require separate GPU validation.`);
