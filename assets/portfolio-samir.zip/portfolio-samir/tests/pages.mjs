/** Check the deployable GitHub Pages artifact, including its private-file boundary. */
import assert from 'node:assert/strict';
import { lstat, mkdir, mkdtemp, readFile, readdir, rm, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildPages } from '../scripts/build-pages.mjs';

const project = fileURLToPath(new URL('../', import.meta.url));
let assertions = 0;
async function files(directory, prefix = '') {
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const name = prefix + entry.name;
    assert.ok(!entry.isSymbolicLink(), 'no symlink in deployment: ' + name); assertions++;
    if (entry.isDirectory()) result.push(...await files(join(directory, entry.name), name + '/'));
    else result.push(name);
  }
  return result.sort();
}

const output = await buildPages();
const expected = ['.nojekyll', 'index.html', 'styles.css', 'app.js', ...await files(join(project, 'assets'), 'assets/')].sort();
assert.deepEqual(await files(output), expected); assertions++;
assert.equal((await readFile(join(output, '.nojekyll'))).length, 0); assertions++;
for (const file of expected.filter(file => file !== '.nojekyll')) {
  assert.deepEqual(await readFile(join(output, file)), await readFile(join(project, file)), 'unchanged public bytes: ' + file); assertions++;
}
assert.ok(!expected.some(file => /^(?:\.openai|\.git|worker|scripts|tests|docs|server|_headers)(?:\/|$)/.test(file))); assertions++;

const temporary = await mkdtemp(join(tmpdir(), 'portfolio-pages-'));
let symlinkChecked = false;
try {
  const source = join(temporary, 'source'), destination = join(temporary, 'output');
  await mkdir(join(source, 'assets'), { recursive: true });
  await mkdir(destination);
  for (const file of ['index.html', 'styles.css', 'app.js']) await writeFile(join(source, file), 'public fixture');
  await writeFile(join(destination, 'sentinel'), 'previous successful build');
  for (const name of ['.env', '.git', 'private.pem', 'private.key', 'client.p12', 'client.pfx', 'data.sqlite', 'data.sqlite3', 'data.db', 'credentials.json', 'secret.json', 'secrets.json', 'id_rsa']) {
    const path = join(source, 'assets', name);
    await writeFile(path, 'must remain private');
    await assert.rejects(buildPages({ source, destination }), /privado|simbólico/); assertions++;
    assert.equal(await readFile(join(destination, 'sentinel'), 'utf8'), 'previous successful build'); assertions++;
    await rm(path);
  }
  try {
    await symlink(join(source, 'index.html'), join(source, 'assets', 'linked.html'));
    symlinkChecked = true;
  } catch (error) {
    if (!['EPERM', 'EACCES', 'ENOSYS'].includes(error.code)) throw error;
  }
  if (symlinkChecked) {
    await assert.rejects(buildPages({ source, destination }), /simbólico/); assertions++;
    assert.equal(await readFile(join(destination, 'sentinel'), 'utf8'), 'previous successful build'); assertions++;
  }
  assert.ok((await lstat(destination)).isDirectory()); assertions++;
} finally {
  await rm(temporary, { recursive: true, force: true });
}
console.log(`PASS GitHub Pages: ${assertions} assertions; exact public files, .nojekyll and private-file rejection${symlinkChecked ? ', including symlinks' : ' (symlink creation unavailable)'}.`);
