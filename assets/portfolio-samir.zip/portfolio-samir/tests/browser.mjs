import assert from 'node:assert/strict';
import fs from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const project=resolve(fileURLToPath(new URL('../',import.meta.url)));
const qaDir=resolve(project,'work/browser-qa');fs.mkdirSync(qaDir,{recursive:true});
const cdpUrl=process.env.CDP_URL||'http://127.0.0.1:9223';
const siteUrl=process.env.PORTFOLIO_URL||'http://127.0.0.1:3000';
const targets=await(await fetch(cdpUrl+'/json/list')).json();
const target=targets.find(t=>t.type==='page');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject});
let id=0;const calls=new Map(),errors=[];
ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.method==='Runtime.exceptionThrown') errors.push(m.params.exceptionDetails.text+' '+(m.params.exceptionDetails.exception?.description||''));if(m.id&&calls.has(m.id)){const p=calls.get(m.id);calls.delete(m.id);m.error?p.reject(m.error):p.resolve(m.result)}};
function send(method,params={}){return new Promise((resolve,reject)=>{const n=++id;calls.set(n,{resolve,reject});ws.send(JSON.stringify({id:n,method,params}));setTimeout(()=>{if(calls.has(n)){calls.delete(n);reject(Error(method+' timed out'))}},12000).unref()})}
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function evaluate(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value}
function check(name,result){assert.ok(result,name);console.log('PASS',name)}
async function key(key,code=key){const vk={Escape:27,ArrowLeft:37,ArrowDown:40,End:35,Home:36}[key]||0;await send('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:vk,nativeVirtualKeyCode:vk});await send('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:vk,nativeVirtualKeyCode:vk})}
async function screenshot(name){const s=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});fs.writeFileSync(resolve(qaDir,name),Buffer.from(s.data,'base64'))}
await send('Page.enable');await send('Runtime.enable');await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});
await send('Page.navigate',{url:siteUrl});await pause(700);await evaluate('document.fonts.ready');
await evaluate('window.SamirI18n?.setLanguage("pt")');
check('locale control exposes all three country flags',await evaluate('document.querySelectorAll(".language-option").length===3&&document.querySelectorAll(".language-option .language-flag").length===3'));
for(const locale of ['en','es','pt']){
 await evaluate(`document.querySelector('#language-toggle').click();document.querySelector('[data-language="${locale}"]').click()`);
 check('locale selection applies '+locale,await evaluate(`document.documentElement.lang===${JSON.stringify(locale==='pt'?'pt-BR':locale)}&&document.querySelector('#language-code').textContent===${JSON.stringify(locale.toUpperCase())}&&document.querySelector('#language-menu').hidden`));
}
check('initial app loads without runtime errors',errors.length===0);
check('all local images load',await evaluate('[...document.images].filter(i=>i.getAttribute("src")).every(i=>i.complete&&i.naturalWidth>0)'));
check('photo layers share size and alignment',await evaluate('(()=>{const a=document.querySelector(".design-photo"),b=document.querySelector(".code-photo"),x=a.getBoundingClientRect(),y=b.getBoundingClientRect();return a.naturalWidth===b.naturalWidth&&a.naturalHeight===b.naturalHeight&&x.x===y.x&&x.y===y.y&&x.width===y.width&&x.height===y.height&&x.top>=document.querySelector("#portrait-scene").getBoundingClientRect().top-1&&getComputedStyle(a).borderRadius==="0px"})()'));
check('Archivo is loaded',await evaluate('document.fonts.check("800 30px Archivo")'));
await screenshot('v9-tested-desktop.png');
check('light theme matches warm paper palette',await evaluate('document.documentElement.dataset.theme==="light"&&getComputedStyle(document.body).backgroundColor==="rgb(250, 247, 243)"'));
await evaluate('document.querySelector("#theme-toggle").click()');
check('dark switch changes palette, accessible action and storage',await evaluate('document.documentElement.dataset.theme==="dark"&&getComputedStyle(document.body).backgroundColor==="rgb(13, 11, 18)"&&localStorage.getItem("samir-theme")==="dark"&&document.querySelector("#theme-toggle").getAttribute("aria-label").includes("claro")'));
await screenshot('v9-dark-desktop.png');
const fullMetrics = await send('Page.getLayoutMetrics');
const fullDark = await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true,clip:{x:0,y:0,width:1440,height:fullMetrics.cssContentSize.height,scale:1}});
fs.writeFileSync(resolve(qaDir,'v9-dark-full.png'),Buffer.from(fullDark.data,'base64'));
await send('Page.reload');await pause(400);
check('dark preference survives reload',await evaluate('document.documentElement.dataset.theme==="dark"'));
await evaluate('document.querySelector("#theme-toggle").click()');
await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'dark'}]});await pause(60);
check('explicit light choice takes priority over dark OS',await evaluate('document.documentElement.dataset.theme==="light"'));
await evaluate('localStorage.removeItem("samir-theme")');await send('Page.reload');await pause(350);
check('without saved choice the page follows dark OS',await evaluate('document.documentElement.dataset.theme==="dark"'));
await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-color-scheme',value:'light'}]});await pause(80);
check('automatic theme reacts to OS changes',await evaluate('document.documentElement.dataset.theme==="light"'));

// Native mouse gesture across the actual range control.
let rect=await evaluate('(()=>{const r=document.querySelector("#portrait-slider").getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()');
await evaluate('window.scrollTo({top:300,behavior:"instant"})');await pause(100);
rect=await evaluate('(()=>{const r=document.querySelector("#portrait-slider").getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()');
const y=rect.y+rect.h/2;
await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:rect.x+rect.w*.08,y,buttons:0});await pause(850);
check('mouse hover without click reveals the complete artwork',await evaluate('Number(document.querySelector("#portrait-slider").value)>99'));
check('hover emphasizes the corresponding heading',await evaluate('Number(getComputedStyle(document.querySelector(".design-side h2")).opacity)>.95&&Number(getComputedStyle(document.querySelector(".code-side h2")).opacity)<.6'));
await screenshot('v9-portrait-art.png');
await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:rect.x+rect.w*.92,y,buttons:0});await pause(850);
check('mouse hover on right reveals the complete natural photo',await evaluate('Number(document.querySelector("#portrait-slider").value)<1'));
await screenshot('v9-portrait-code.png');

await send('Input.dispatchMouseEvent',{type:'mousePressed',x:rect.x+rect.w*.5,y,button:'left',clickCount:1});
await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:rect.x+rect.w*.82,y,button:'left',buttons:1});
await send('Input.dispatchMouseEvent',{type:'mouseReleased',x:rect.x+rect.w*.82,y,button:'left',clickCount:1});
check('native mouse drag reveals design',await evaluate('Number(document.querySelector("#portrait-slider").value)>75'));
await evaluate('document.querySelector("#portrait-slider").focus()');const value=await evaluate('Number(document.querySelector("#portrait-slider").value)');await key('ArrowLeft');
check('native keyboard arrow changes portrait',await evaluate('Number(document.querySelector("#portrait-slider").value)')===value-1);
await evaluate('document.querySelector("[data-portrait=\\"0\\"]").click()');
check('code preset reaches zero',await evaluate('document.querySelector("#portrait-scene").style.getPropertyValue("--split")==="0%"'));
await evaluate('document.querySelector("#tab-sobre").focus()');await key('ArrowDown');
check('editor native keyboard selects studies and moves focus',await evaluate('document.activeElement.id==="tab-estudos"&&!document.querySelector("#panel-estudos").hidden&&document.querySelector("#panel-sobre").hidden'));
await evaluate('document.querySelector(".explorer-file[data-open-file=estudos]").click()');
check('explorer shortcut selects studies and active file',await evaluate('!document.querySelector("#panel-estudos").hidden&&document.querySelector(".explorer-file[data-open-file=estudos]").getAttribute("aria-current")=="true"&&document.querySelector("#editor-language").textContent=="JSON"'));
check('studies file is valid factual JSON',await evaluate('JSON.parse(document.querySelector("#panel-estudos code").textContent).idiomas.ingles==="básico"'));
await key('End');check('editor End selects projects',await evaluate('document.activeElement.id==="tab-projetos"&&!document.querySelector("#panel-projetos").hidden'));
await evaluate('document.querySelector("[data-filter=\\"web\\"]").click()');check('web filter exposes two projects',await evaluate('[...document.querySelectorAll(".project-card")].filter(e=>!e.hidden).length===2'));
await evaluate('document.querySelector("[data-tech=\\"python\\"]").click();document.querySelector("#tech-detail-link").click()');await pause(100);
check('tech project link reveals filtered API project',await evaluate('!document.querySelector("#projeto-jogos").hidden&&location.hash==="#projeto-jogos"'));
await evaluate('document.querySelector("[data-preview=\\"fruta\\"]").click()');check('native modal opens with close focused',await evaluate('document.querySelector("#project-dialog").open&&document.activeElement.id==="close-preview"'));
await key('Escape','Escape');await pause(80);check('native Escape closes modal and restores focus',await evaluate('!document.querySelector("#project-dialog").open&&document.activeElement.dataset.preview==="fruta"'));
check('curriculum is a real downloadable PDF',await evaluate('(async()=>{const a=document.querySelector(".header-cv");const r=await fetch(a.href);const b=new Uint8Array(await r.arrayBuffer());return a.hasAttribute("download")&&r.ok&&r.headers.get("content-type")==="application/pdf"&&String.fromCharCode(...b.slice(0,5))==="%PDF-"&&b.length>20000})()'));
fs.mkdirSync(resolve(qaDir,'downloads'),{recursive:true});
fs.rmSync(resolve(qaDir,'downloads/Samir-Gedeon-Machado-Curriculo.pdf'),{force:true});
await send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:resolve(qaDir,'downloads')});
await evaluate('document.querySelector(".header-cv").click()');await pause(600);
check('source ZIP has a working download link',await evaluate('(async()=>{const a=document.querySelector(".source-download");const r=await fetch(a.href);const b=new Uint8Array(await r.arrayBuffer());return a.hasAttribute("download")&&r.ok&&r.headers.get("content-type")==="application/zip"&&b[0]===80&&b[1]===75&&b.length>100000})()'));
check('clicking CV actually downloads the PDF',fs.existsSync(resolve(qaDir,'downloads/Samir-Gedeon-Machado-Curriculo.pdf')));
check('download matches source PDF',fs.readFileSync(resolve(qaDir,'downloads/Samir-Gedeon-Machado-Curriculo.pdf')).equals(fs.readFileSync(resolve(project,'assets/curriculo-samir-gedeon-machado.pdf'))));
// Select every tech and check it has real explanatory content.
check('all eight technology choices update the detail',await evaluate('(()=>{const a=[...document.querySelectorAll("[data-tech]")];return a.length===8&&a.every(b=>{b.click();return b.getAttribute("aria-pressed")==="true"&&document.querySelector("#tech-detail-copy").textContent.length>60})})()'));
await evaluate('window.scrollTo({top:document.querySelector("#tecnologias").offsetTop-100,behavior:"instant"})');await pause(200);
const rotation=await evaluate('getComputedStyle(document.querySelector(".tech-orbit")).transform');
await evaluate('window.scrollBy({top:230,behavior:"instant"})');await pause(200);
check('3D technology arrangement responds to real scroll',rotation!==await evaluate('getComputedStyle(document.querySelector(".tech-orbit")).transform'));
await evaluate('window.scrollTo({top:document.querySelector("#contato").offsetTop,behavior:"instant"})');await pause(200);
let contact=await evaluate('(()=>{const r=document.querySelector("#contato").getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()');
for(let i=0;i<8;i++){await send('Input.dispatchMouseEvent',{type:'mouseMoved',x:180+i*40,y:Math.max(50,contact.y+150)});await pause(30)}
check('pointer gesture activates the actual WebGL fluid',await evaluate('(()=>{const c=document.querySelector("#ink-canvas");const gl=c.getContext("webgl2")||c.getContext("webgl");return !c.hidden&&gl&&!gl.isContextLost()&&c.width>100&&gl.getParameter(gl.CURRENT_PROGRAM)!==null})()'));
await screenshot('v9-fluid-contact.png');
await pause(7100);check('trail hides after its full dissipation lifetime',await evaluate('(()=>{const c=document.querySelector("#ink-canvas");return c.hidden})()'));
await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});await pause(100);
check('system reduced motion disables canvas and scene animation',await evaluate('document.documentElement.dataset.motion==="reduced"&&document.querySelector("#motion-toggle").disabled&&document.querySelector("#ink-canvas").hidden&&document.querySelector("#tecnologias").classList.contains("tech-static")'));
await send('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'no-preference'}]});await pause(100);
await evaluate('document.querySelector("#motion-toggle").click()');check('manual reduced motion applies',await evaluate('document.documentElement.dataset.motion==="reduced"&&document.querySelector("#ink-canvas").hidden'));
await evaluate('document.querySelector("#motion-toggle").click()');
// Real responsive layout, not just font-width estimates.
for(const width of [320,375,414,768,1024,1440]){
 await send('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:width<600});await pause(100);await evaluate('window.scrollTo({top:0,behavior:"instant"})');await evaluate('document.fonts.ready');
 check('layout has no horizontal overflow at '+width+'px',await evaluate('document.documentElement.scrollWidth<=innerWidth'));
 await evaluate('document.querySelector("#theme-toggle").click()');
 check('dark layout has no horizontal overflow at '+width+'px',await evaluate('document.documentElement.scrollWidth<=innerWidth&&document.documentElement.dataset.theme==="dark"'));
 check('theme button stays inside viewport at '+width+'px',await evaluate('(()=>{const r=document.querySelector("#theme-toggle").getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.width>=30})()'));
 if(width===375)await screenshot('v9-dark-mobile.png');
 await evaluate('document.querySelector("#theme-toggle").click()');

 for(const locale of ['en','es','pt']){
  await evaluate(`window.SamirI18n.setLanguage('${locale}')`);
  check('translated layout fits '+width+'px in '+locale,await evaluate('document.documentElement.scrollWidth<=innerWidth'));
  await evaluate('document.querySelector("#language-toggle").click()');
  check('locale menu fits '+width+'px in '+locale,await evaluate('(()=>{const r=document.querySelector("#language-menu").getBoundingClientRect();return r.left>=0&&r.right<=innerWidth})()'));
  await key('Escape','Escape');
 }
 check('editor orientation matches layout at '+width+'px',await evaluate('document.querySelector(".editor-tablist").getAttribute("aria-orientation")==="horizontal"'));
 if(width===375){await evaluate('document.querySelector("#portrait-slider").value=50;document.querySelector("#portrait-slider").dispatchEvent(new Event("input"))');await screenshot('v9-tested-mobile.png');}
}
await send('Emulation.setDeviceMetricsOverride',{width:375,height:900,deviceScaleFactor:1,mobile:true});await send('Emulation.setTouchEmulationEnabled',{enabled:true});await evaluate('document.querySelector("#portrait-slider").scrollIntoView({block:"center",behavior:"instant"})');await pause(100);
rect=await evaluate('(()=>{const r=document.querySelector("#portrait-slider").getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height}})()');
const ty=rect.y+rect.h/2;
await send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:rect.x+rect.w*.5,y:ty}]});
for(let i=0;i<6;i++){await send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:rect.x+rect.w*(.5+i*.065),y:ty}]});await pause(20)}
await send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
check('native touch drag reveals design on mobile',await evaluate('Number(document.querySelector("#portrait-slider").value)>70'));
check('mobile uses static lightweight technology grid',await evaluate('document.querySelector("#tecnologias").classList.contains("tech-static")&&getComputedStyle(document.querySelector(".tech-pieces")).display==="grid"&&document.querySelector("#ink-canvas").hidden'));
await send('Emulation.setTouchEmulationEnabled',{enabled:false});
await send('Emulation.setScriptExecutionDisabled',{value:true});await send('Page.reload');await pause(400);
check('no-JS retains every project, editor content and CV',await evaluate('[...document.querySelectorAll(".project-card")].every(e=>!e.hidden)&&[...document.querySelectorAll(".editor-panel")].every(e=>!e.hidden)&&document.querySelector(".header-cv").hasAttribute("download")&&document.querySelector("#portrait-slider").hidden'));
await send('Emulation.setScriptExecutionDisabled',{value:false});await send('Emulation.setDeviceMetricsOverride',{width:1440,height:1000,deviceScaleFactor:1,mobile:false});await send('Page.reload');await pause(400);
check('no uncaught browser exceptions through all scenarios',errors.length===0);
console.log('BROWSER QA COMPLETE');ws.close();
