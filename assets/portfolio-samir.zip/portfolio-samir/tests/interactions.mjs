/** App behavior tests use a small emulated DOM; no browser rendering. */
import assert from 'node:assert/strict';
import {fixture} from './dom-fixture.mjs';

let passed = 0;
function test(name, callback) {
  callback();
  passed++;
  console.log(`PASS ${name}`);
}
function visibleProjects(env) { return env.qa('.project-card').filter(card => !card.hidden).map(card => card.attrs.id); }
function selectedTabs(env) { return env.qa('[data-editor]').filter(tab => tab.getAttribute('aria-selected') === 'true'); }

test('progressive controls activate; all four projects remain initially visible', () => {
  const e = fixture();
  assert.equal(visibleProjects(e).length, 4);
  for (const selector of ['.portrait-presets', '#portrait-slider', '.editor-tablist', '.project-filters', '#motion-toggle']) assert.equal(e.q(selector).hidden, false);
});

test('portrait range reveals design and code and describes its value accessibly', () => {
  const e = fixture();
  const range = e.q('#portrait-slider');
  assert.equal(e.q('#portrait-scene').styles.get('--split'), '50%');
  for (const value of ['0', '25', '100']) {
    range.value = value; range.emit('input', { target: range });
    assert.equal(e.q('#portrait-scene').styles.get('--split'), `${value}%`);
    assert.ok(range.getAttribute('aria-valuetext')?.length > 0);
  }
});

test('portrait preset buttons update the range and its rendered split', () => {
  const e = fixture();
  for (const button of e.qa('[data-portrait]')) {
    button.click();
    assert.equal(e.q('#portrait-slider').value, button.dataset.portrait);
    assert.equal(e.q('#portrait-scene').styles.get('--split'), `${button.dataset.portrait}%`);
  }
});

test('editor tabs expose exactly one matching panel with accessible selected state', () => {
  const e = fixture();
  assert.equal(selectedTabs(e).length, 1);
  assert.equal(e.q('#panel-sobre').hidden, false);
  for (const tab of e.qa('[data-editor]')) {
    tab.click();
    assert.equal(selectedTabs(e).length, 1);
    assert.equal(tab.getAttribute('aria-selected'), 'true');
    assert.equal(tab.tabIndex, 0);
    for (const other of e.qa('[data-editor]')) {
      assert.equal(e.q(`#panel-${other.dataset.editor}`).hidden, tab !== other);
      if (tab !== other) assert.equal(other.tabIndex, -1);
    }
  }
});

test('editor keyboard arrows and Home/End move selection and focus', () => {
  const e = fixture();
  const tabs = e.qa('[data-editor]');
  let prevented = 0;
  const press = (tab, key) => tab.emit('keydown', { key, target: tab, preventDefault: () => prevented++ });
  tabs[0].focus(); press(tabs[0], 'ArrowDown');
  assert.equal(e.document.activeElement, tabs[1]);
  assert.equal(tabs[1].getAttribute('aria-selected'), 'true');
  press(tabs[1], 'End'); assert.equal(e.document.activeElement, tabs[2]);
  press(tabs[2], 'ArrowDown'); assert.equal(e.document.activeElement, tabs[0]);
  press(tabs[0], 'ArrowUp'); assert.equal(e.document.activeElement, tabs[2]);
  press(tabs[2], 'Home'); assert.equal(e.document.activeElement, tabs[0]);
  assert.equal(prevented, 5);
});

test('closing an editor file selects the next open tab and preserves a different active file', () => {
  const e = fixture();
  e.q('[data-close-file="sobre"]').click();
  assert.equal(e.q('#tab-sobre').hidden, true);
  assert.equal(e.q('[data-editor-shell="sobre"]').hidden, true);
  assert.equal(e.q('#panel-sobre').hidden, true);
  assert.equal(e.q('#tab-estudos').getAttribute('aria-selected'), 'true');
  assert.equal(e.document.activeElement, e.q('#tab-estudos'));
  assert.equal(e.q('[data-close-file="estudos"]').tabIndex, 0);
  e.q('[data-close-file="projetos"]').click();
  assert.equal(e.q('#tab-estudos').getAttribute('aria-selected'), 'true');
  assert.equal(e.q('#editor-language').textContent, 'JSON');
  assert.equal(selectedTabs(e).length, 1);
});

test('editor Delete closes the focused tab and keyboard navigation skips closed files', () => {
  const e = fixture();
  const press = (tab, key) => tab.emit('keydown', { key, target: tab, preventDefault() {} });
  press(e.q('#tab-estudos'), 'Delete');
  assert.equal(e.q('#tab-estudos').hidden, true);
  press(e.q('#tab-sobre'), 'ArrowRight');
  assert.equal(e.document.activeElement, e.q('#tab-projetos'));
  press(e.q('#tab-projetos'), 'Home');
  assert.equal(e.document.activeElement, e.q('#tab-sobre'));
});

test('closing every editor tab exposes a useful empty state and file links reopen content', () => {
  const e = fixture();
  for (const close of e.qa('[data-close-file]')) close.click();
  assert.equal(selectedTabs(e).length, 0);
  assert.ok(e.qa('.editor-panel').every(panel => panel.hidden));
  assert.equal(e.q('#editor-empty').hidden, false);
  assert.equal(e.q('#editor-language').textContent, 'Workspace');
  assert.equal(e.document.activeElement, e.q('#editor-empty').querySelector('[data-open-file]'));
  e.q('#editor-empty').querySelector('[data-open-file="projetos"]').click();
  assert.equal(e.q('#editor-empty').hidden, true);
  assert.equal(e.q('#tab-projetos').hidden, false);
  assert.equal(e.q('#tab-sobre').hidden, true);
  assert.equal(e.q('#panel-projetos').hidden, false);
  assert.equal(e.document.activeElement, e.q('#tab-projetos'));
  assert.equal(e.q('#editor-language').textContent, 'JavaScript');
});

test('file picker can reopen a closed file and Escape returns focus to its trigger', () => {
  const e = fixture();
  const picker = e.q('.editor-files-menu');
  e.q('[data-close-file="estudos"]').click();
  picker.setAttribute('open', '');
  picker.querySelector('[data-open-file="estudos"]').click();
  assert.equal(picker.hasAttribute('open'), false);
  assert.equal(e.q('#tab-estudos').hidden, false);
  assert.equal(e.q('#tab-estudos').getAttribute('aria-selected'), 'true');
  picker.setAttribute('open', '');
  picker.emit('keydown', { key: 'Escape', preventDefault() {} });
  assert.equal(picker.hasAttribute('open'), false);
  assert.equal(e.document.activeElement, picker.querySelector('summary'));
});

test('technology choices expose one selected item and a real related project', () => {
  const e = fixture();
  const buttons = e.qa('[data-tech]');
  assert.equal(buttons.length, 8);
  for (const button of buttons) {
    button.click();
    assert.equal(button.getAttribute('aria-pressed'), 'true');
    assert.equal(buttons.filter(other => other.getAttribute('aria-pressed') === 'true').length, 1);
    assert.ok(e.q('#tech-detail-title').textContent.length > 0);
    assert.equal(e.q('#tech-core-label').textContent, e.q('#tech-detail-title').textContent);
    assert.equal(e.q('#tecnologias').dataset.activeTech, button.dataset.tech);
    assert.ok(e.q('#tech-link-path').getAttribute('d').startsWith('M'));
    assert.equal(e.q('#tech-link-path').getAttribute('d'), e.q('#tech-link-flow').getAttribute('d'));
    assert.ok(e.q('#tech-detail-copy').textContent.length > 0);
    const target = e.q('#tech-detail-link').href;
    assert.ok(target.startsWith('#projeto-'));
    assert.ok(e.document.getElementById(target.slice(1)));
    assert.ok(e.q('#tech-detail-link').getAttribute('aria-label').length > 0);
  }
});

test('reducing movement cancels queued spatial frames and restores the static scene', () => {
  const e = fixture();
  e.flush();
  assert.equal(e.q('.tech-orbit').styles.size, 3);
  e.q('#motion-toggle').click();
  assert.equal(e.q('#tecnologias').classList.contains('tech-static'), true);
  assert.equal(e.q('.tech-orbit').styles.size, 0);
  assert.equal(e.frames.size, 0);
});

test('technology pointer depth returns to rest and disables with reduced motion', () => {
  const e = fixture();
  const orbit = e.q('.tech-orbit');
  const stage = e.q('.tech-stage');
  e.flush();
  const restX = orbit.styles.get('--tech-rx');
  const restY = orbit.styles.get('--tech-ry');
  const firstPath = e.q('#tech-link-path').getAttribute('d');
  e.qa('[data-tech]').find(button => button.dataset.tech === 'python').click();
  assert.notEqual(e.q('#tech-link-path').getAttribute('d'), firstPath);
  stage.emit('pointermove', { pointerType: 'mouse', buttons: 0, clientX: 760, clientY: 80 });
  e.flush();
  assert.notEqual(orbit.styles.get('--tech-rx'), restX);
  assert.notEqual(orbit.styles.get('--tech-ry'), restY);
  stage.emit('pointerleave'); e.flush();
  assert.equal(orbit.styles.get('--tech-rx'), restX);
  assert.equal(orbit.styles.get('--tech-ry'), restY);
  assert.equal(e.q('#tecnologias').classList.contains('is-tech-active'), true);
  e.q('#motion-toggle').click();
  assert.equal(e.q('#tecnologias').classList.contains('is-tech-active'), false);
  stage.emit('pointermove', { pointerType: 'mouse', buttons: 0, clientX: 760, clientY: 80 }); e.flush();
  assert.equal(orbit.styles.size, 0);
});

test('filters show correct categories and announce counts', () => {
  const e = fixture();
  for (const button of e.qa('[data-filter]')) {
    button.click();
    const expected = button.dataset.filter === 'all' ? 4 : 2;
    assert.equal(visibleProjects(e).length, expected);
    assert.equal(e.q('#filter-status').textContent, `${expected} projetos exibidos.`);
    assert.equal(button.getAttribute('aria-pressed'), 'true');
  }
});

test('same-hash anchor click reveals a project hidden by a later filter', () => {
  const e = fixture();
  e.setHash('#projeto-drew');
  e.qa('[data-filter]').find(button => button.dataset.filter === 'api').click();
  assert.equal(e.q('#projeto-drew').hidden, true);
  // The same destination may be reached through any internal link, including a child icon.
  const { child } = e.makeAnchor('#projeto-drew');
  child.click();
  assert.equal(e.location.hash, '#projeto-drew');
  assert.equal(e.q('#projeto-drew').hidden, false);
  assert.equal(visibleProjects(e).length, 4);
  assert.equal(e.q('#projeto-drew').scrolls.length, 1);
});

test('hashchange reveals a filtered target; malformed hashes do not throw', () => {
  const e = fixture();
  e.qa('[data-filter]').find(button => button.dataset.filter === 'web').click();
  e.setHash('#projeto-estoque');
  assert.equal(e.q('#projeto-estoque').hidden, false);
  assert.equal(e.q('#projeto-estoque').scrolls.length, 1);
  assert.doesNotThrow(() => e.setHash('#%broken'));
});

test('OS reduced motion overrides saved full choice and updates the action', () => {
  const e = fixture({ reduce: true, savedMotion: 'full' });
  assert.equal(e.document.documentElement.dataset.motion, 'reduced');
  assert.equal(e.q('#motion-toggle').disabled, true);
  e.motion.matches = false; e.motion.emit('change');
  assert.equal(e.document.documentElement.dataset.motion, 'full');
  assert.equal(e.q('#motion-toggle').disabled, false);
});

test('motion action persists choice while OS preference always takes precedence', () => {
  const e = fixture();
  e.q('#motion-toggle').click();
  assert.equal(e.storage.get('samir-motion'), 'reduced');
  assert.equal(e.document.documentElement.dataset.motion, 'reduced');
  e.q('#motion-toggle').click();
  assert.equal(e.storage.get('samir-motion'), 'full');
  e.motion.matches = true; e.motion.emit('change');
  assert.equal(e.document.documentElement.dataset.motion, 'reduced');
  assert.equal(e.q('#motion-toggle').disabled, true);
});

test('low-power hints do not block portrait, editor or project content', () => {
  for (const options of [{ compact: true }, { saveData: true }, { memory: 4 }, { cores: 2 }]) {
    const e = fixture(options);
    assert.equal(visibleProjects(e).length, 4);
    assert.equal(e.q('#portrait-slider').hidden, false);
    e.qa('[data-editor]')[1].click();
    assert.equal(e.q('#panel-estudos').hidden, false);
  }
});

test('preview callbacks set actual asset/link, open dialog, focus close and restore trigger', () => {
  const e = fixture();
  const trigger = e.qa('[data-preview]').find(button => button.dataset.preview === 'fruta');
  trigger.focus(); trigger.click();
  assert.equal(e.q('#project-dialog').open, true);
  assert.equal(e.q('#preview-image').src, 'assets/projects/fruta.png');
  assert.equal(e.q('#preview-repo').href, 'https://github.com/SamirGedeon/Site-Refri');
  assert.equal(e.document.activeElement, e.q('#close-preview'));
  assert.equal(e.document.body.classList.contains('dialog-open'), true);
  e.q('#close-preview').click();
  assert.equal(e.q('#project-dialog').open, false);
  assert.equal(e.document.activeElement, trigger);
  assert.equal(e.document.body.classList.contains('dialog-open'), false);
  trigger.click();
  e.q('#project-dialog').emit('click', { clientX: -20, clientY: -20 });
  assert.equal(e.q('#project-dialog').open, false);
});

test('unsupported dialog keeps preview controls hidden without blocking content', () => {
  const e = fixture({ dialogSupported: false, storageBlocked: true });
  assert.equal(e.qa('[data-preview]').every(button => button.hidden), true);
  assert.equal(visibleProjects(e).length, 4);
  assert.doesNotThrow(() => e.q('#motion-toggle').click());
});


test('portrait follows mouse without clicking and reaches both complete layers', () => {
  const e = fixture();
  e.q('#portrait-scene').emit('pointermove', { pointerType: 'mouse', buttons: 0, clientX: 60 });
  for (let i = 0; i < 45; i++) e.flush();
  assert.equal(Number(e.q('#portrait-slider').value), 100);
  e.q('#portrait-scene').emit('pointermove', { pointerType: 'mouse', buttons: 0, clientX: 740 });
  for (let i = 0; i < 45; i++) e.flush();
  assert.equal(Number(e.q('#portrait-slider').value), 0);
});
test('automatic portrait motion cancels for device reduced motion', () => {
  const e = fixture();
  e.q('#portrait-scene').emit('pointermove', { pointerType: 'mouse', buttons: 0, clientX: 40 });
  e.motion.matches = true; e.motion.emit('change');
  for (let i = 0; i < 45; i++) e.flush();
  assert.equal(e.q('#portrait-slider').value, '50');
  assert.equal(e.frames.size, 0);
});
test('theme follows OS until an explicit persistent user choice', () => {
  const e = fixture();
  assert.equal(e.document.documentElement.dataset.theme, 'light');
  e.scheme.matches = true; e.scheme.emit('change');
  assert.equal(e.document.documentElement.dataset.theme, 'dark');
  e.q('#theme-toggle').click();
  assert.equal(e.document.documentElement.dataset.theme, 'light');
  assert.equal(e.storage.get('samir-theme'), 'light');
  e.scheme.emit('change');
  assert.equal(e.document.documentElement.dataset.theme, 'light');
  const saved = fixture({ savedTheme: 'dark' });
  assert.equal(saved.document.documentElement.dataset.theme, 'dark');
  assert.equal(saved.q('#theme-toggle').getAttribute('aria-label'), 'Ativar modo claro');
});
test('theme controls still work without localStorage', () => {
  const e = fixture({ dark: true, storageBlocked: true });
  assert.equal(e.document.documentElement.dataset.theme, 'dark');
  e.q('#theme-toggle').click();
  assert.equal(e.document.documentElement.dataset.theme, 'light');
});

test('complete portrait modes replace opposite content and restore both sides at the center', () => {
  const e = fixture();
  const range = e.q('#portrait-slider');
  range.value = 100; range.emit('input');
  assert.equal(e.q('#portrait-scene').dataset.portraitMode, 'design');
  assert.equal(e.q('.code-side').hidden, true);
  assert.equal(e.q('.code-rain').hidden, true);
  assert.equal(e.q('.design-side').hidden, false);
  assert.equal(e.q('.art-notes').hidden, false);
  assert.equal(e.q('.code-notes').hidden, true);
  range.value = 0; range.emit('input');
  assert.equal(e.q('#portrait-scene').dataset.portraitMode, 'code');
  assert.equal(e.q('.design-side').hidden, true);
  assert.equal(e.q('.code-side').hidden, false);
  assert.equal(e.q('.code-rain').hidden, false);
  assert.equal(e.q('.art-notes').hidden, true);
  assert.equal(e.q('.code-notes').hidden, false);
  range.value = 50; range.emit('input');
  assert.equal(e.q('#portrait-scene').dataset.portraitMode, 'balanced');
  assert.equal(e.q('.design-side').hidden, false);
  assert.equal(e.q('.code-side').hidden, false);
  assert.equal(e.q('.art-notes').hidden, true);
  assert.equal(e.q('.code-notes').hidden, true);
});
test('manual complete portrait modes remain available with reduced movement and constrained devices', () => {
  for (const options of [{ reduce: true }, { compact: true }, { saveData: true }]) {
    const e = fixture(options);
    e.qa('[data-portrait]').find(button => button.dataset.portrait === '100').click();
    assert.equal(e.q('.art-notes').hidden, false);
    assert.equal(e.q('.code-side').hidden, true);
    e.qa('[data-portrait]').find(button => button.dataset.portrait === '0').click();
    assert.equal(e.q('.code-notes').hidden, false);
    assert.equal(e.q('.design-side').hidden, true);
  }
});

console.log(`\n${passed} logical interaction tests passed in an emulated DOM. No browser validation performed.`);
