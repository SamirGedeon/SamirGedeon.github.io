"""Optional Linux native EGL/GLES replay. WebGL1 format enums map to GLES3 equivalents."""
import ctypes as C,json,struct,zlib,pathlib,time,sys
mode=sys.argv[1] if len(sys.argv)>1 else "full"
metrics={}
qa_dir=pathlib.Path(__file__).resolve().parents[2]/'work'/'gpu-qa'
qa_dir.mkdir(parents=True,exist_ok=True)
from ctypes import c_void_p as P,c_int as I,c_uint as U,c_float as F,c_char_p as S
import ctypes as C
from ctypes import c_void_p as P,c_int as I,c_uint as U
E=C.CDLL('libEGL.so.1')
E.eglGetProcAddress.argtypes=[C.c_char_p];E.eglGetProcAddress.restype=P
get=C.CFUNCTYPE(P,U,P,C.POINTER(I))(E.eglGetProcAddress(b'eglGetPlatformDisplayEXT'))
d=get(0x31DD,None,None)
E.eglInitialize.argtypes=[P,C.POINTER(I),C.POINTER(I)];E.eglInitialize.restype=U
major=I();minor=I();assert E.eglInitialize(d,C.byref(major),C.byref(minor))
E.eglBindAPI.argtypes=[U];E.eglBindAPI.restype=U;assert E.eglBindAPI(0x30A0)
a=(I*15)(0x3033,1,0x3040,0x0040,0x3024,8,0x3023,8,0x3022,8,0x3021,8,0x3038)
E.eglChooseConfig.argtypes=[P,C.POINTER(I),C.POINTER(P),I,C.POINTER(I)];E.eglChooseConfig.restype=U
config=P();n=I();assert E.eglChooseConfig(d,a,C.byref(config),1,C.byref(n)) and n.value
E.eglCreatePbufferSurface.argtypes=[P,P,C.POINTER(I)];E.eglCreatePbufferSurface.restype=P
s=E.eglCreatePbufferSurface(d,config,(I*5)(0x3057,800,0x3056,440,0x3038));assert s
E.eglCreateContext.argtypes=[P,P,P,C.POINTER(I)];E.eglCreateContext.restype=P
ctx=E.eglCreateContext(d,config,None,(I*3)(0x3098,3,0x3038));assert ctx
E.eglMakeCurrent.argtypes=[P,P,P,P];E.eglMakeCurrent.restype=U;assert E.eglMakeCurrent(d,s,s,ctx)
gs=C.CFUNCTYPE(C.c_char_p,U)(E.eglGetProcAddress(b'glGetString'))
print('EGL',major.value,minor.value,'GL:',gs(0x1F02).decode(),'Renderer:',gs(0x1F01).decode())

def gl(name,restype,args):
 addr=E.eglGetProcAddress(name.encode());assert addr,name
 return C.CFUNCTYPE(restype,*args)(addr)
err=gl('glGetError',U,[])
objects={};uniforms={};compiled=linked=draws=0
functions={
 'compileShader':gl('glCompileShader',None,[U]),'attachShader':gl('glAttachShader',None,[U,U]),'bindAttribLocation':gl('glBindAttribLocation',None,[U,U,S]),'linkProgram':gl('glLinkProgram',None,[U]),'deleteShader':gl('glDeleteShader',None,[U]),'useProgram':gl('glUseProgram',None,[U]),'uniform1i':gl('glUniform1i',None,[I,I]),'uniform1f':gl('glUniform1f',None,[I,F]),'uniform2f':gl('glUniform2f',None,[I,F,F]),'uniform3f':gl('glUniform3f',None,[I,F,F,F]),'bindBuffer':gl('glBindBuffer',None,[U,U]),'enableVertexAttribArray':gl('glEnableVertexAttribArray',None,[U]),'vertexAttribPointer':gl('glVertexAttribPointer',None,[U,I,U,U,I,P]),'bindTexture':gl('glBindTexture',None,[U,U]),'texParameteri':gl('glTexParameteri',None,[U,U,I]),'texImage2D':gl('glTexImage2D',None,[U,I,I,I,I,I,U,U,P]),'bindFramebuffer':gl('glBindFramebuffer',None,[U,U]),'framebufferTexture2D':gl('glFramebufferTexture2D',None,[U,U,U,U,I]),'deleteProgram':gl('glDeleteProgram',None,[U]),'activeTexture':gl('glActiveTexture',None,[U]),'viewport':gl('glViewport',None,[I,I,I,I]),'clearColor':gl('glClearColor',None,[F,F,F,F]),'clear':gl('glClear',None,[U]),'disable':gl('glDisable',None,[U]),'enable':gl('glEnable',None,[U]),'drawArrays':gl('glDrawArrays',None,[U,I,I]),'blendFunc':gl('glBlendFunc',None,[U,U])}
getloc=gl('glGetUniformLocation',I,[U,S]);shaderiv=gl('glGetShaderiv',None,[U,U,C.POINTER(I)]);programiv=gl('glGetProgramiv',None,[U,U,C.POINTER(I)])
getshaderlog=gl('glGetShaderInfoLog',None,[U,I,C.POINTER(I),P]);getprogramlog=gl('glGetProgramInfoLog',None,[U,I,C.POINTER(I),P])
checkfbo=gl('glCheckFramebufferStatus',U,[U]);read=gl('glReadPixels',None,[I,I,I,I,U,U,P])
def decode(arg):
 if isinstance(arg,dict):
  if 'ref'in arg:return objects[arg['ref']]
  if 'uniform'in arg:
   p,name=arg['uniform'];key=(p,name)
   if key not in uniforms:uniforms[key]=getloc(objects[p],name.encode())
   return uniforms[key]
  if 'array'in arg:return (F*len(arg['data']))(*arg['data'])
 if isinstance(arg,str):return arg.encode()
 return 0 if arg is None else arg

def capture(name):
 w,h=800,440;data=(C.c_ubyte*(w*h*4))();read(0,0,w,h,6408,5121,data)
 rgba=bytes(data);rows=[];colored=0;alphaSum=sum(rgba[3::4]);rgbSum=sum(v for i,v in enumerate(rgba) if i%4!=3)
 for y in range(h-1,-1,-1):
  row=bytearray()
  for x in range(w):
   i=(y*w+x)*4;r,g,b,a=rgba[i:i+4]
   if a>2:colored+=1
   row.extend((min(255,r+255-a),min(255,g+255-a),min(255,b+255-a)))
  rows.append(b'\0'+row)
 def chunk(tag,content):return struct.pack('>I',len(content))+tag+content+struct.pack('>I',zlib.crc32(tag+content)&0xffffffff)
 png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows),6))+chunk(b'IEND',b'')
 target=qa_dir/name;target.write_bytes(png);metrics[name]={'alpha':alphaSum,'rgb':rgbSum,'colored':colored}
 if '-clear.' in name:assert alphaSum==0 and rgbSum==0,(name,alphaSum,rgbSum)
 else:assert colored>1000,(name,colored)
 print('CAPTURE',target.name,'colored pixels',colored,flush=True)

commands=json.loads((qa_dir/f'fluid-v8-{mode}-trace.json').read_text());start=time.time()
for index,c in enumerate(commands):
 name=c['fn'];args=[decode(a) for a in c['args']]
 if name.startswith('create'):
  kind=name[6:]
  if kind=='Shader':value=gl('glCreateShader',U,[U])(*args)
  elif kind=='Program':value=gl('glCreateProgram',U,[])()
  else:
   value=U();gl('glGen'+{'Buffer':'Buffers','Texture':'Textures','Framebuffer':'Framebuffers'}[kind],None,[I,C.POINTER(U)])(1,C.byref(value));value=value.value
  assert value;objects[c['result']]=value
 elif name=='shaderSource':
  strings=(S*1)(args[1]);gl('glShaderSource',None,[U,I,C.POINTER(S),C.POINTER(I)])(args[0],1,strings,None)
 elif name=='bufferData':gl('glBufferData',None,[U,C.c_ssize_t,P,U])(args[0],C.sizeof(args[1]),args[1],args[2])
 elif name=='uniform4fv':gl('glUniform4fv',None,[I,I,P])(args[0],len(args[1])//4,args[1])
 elif name in ['deleteTexture','deleteFramebuffer','deleteBuffer']:
  obj=U(args[0]);gl('glDelete'+{'deleteTexture':'Textures','deleteFramebuffer':'Framebuffers','deleteBuffer':'Buffers'}[name],None,[I,C.POINTER(U)])(1,C.byref(obj))
 elif name=='capture':capture(c['args'][0])
 else:
  if name=='texImage2D' and args[7]==36193:
   args[7]=5131
   if args[2]==6408:args[2]=34842
  functions[name](*args)
  if name=='compileShader':
   status=I();shaderiv(args[0],35713,C.byref(status));buf=C.create_string_buffer(8192)
   if not status.value:getshaderlog(args[0],8192,None,buf);raise RuntimeError(buf.value.decode())
   compiled+=1
  elif name=='linkProgram':
   status=I();programiv(args[0],35714,C.byref(status));buf=C.create_string_buffer(8192)
   if not status.value:getprogramlog(args[0],8192,None,buf);raise RuntimeError(buf.value.decode())
   linked+=1
  elif name=='framebufferTexture2D':assert checkfbo(36160)==36053,'incomplete actual framebuffer'
  elif name=='drawArrays':draws+=1
 error=err()
 if error:raise RuntimeError(f'GL error {hex(error)} at command {index} {name} {c["args"]}')
base=metrics[f'v8-{mode}-final.png'];masked=metrics[f'v8-{mode}-mask.png'];half=metrics[f'v8-{mode}-half.png']
assert .15 < masked['alpha']/base['alpha'] < .22,metrics
assert .46 < half['alpha']/base['alpha'] < .54,metrics
assert .46 < half['rgb']/base['rgb'] < .54,metrics
print('PASS premultiplied mask/fade ratios',round(masked['alpha']/base['alpha'],3),round(half['alpha']/base['alpha'],3),round(half['rgb']/base['rgb'],3))
print('PASS native GLES',compiled,'shaders',linked,'programs',draws,'draws',round(time.time()-start,2),'seconds',flush=True)
(qa_dir/f'fluid-v8-{mode}-native-result.json').write_text(json.dumps({'shaders':compiled,'programs':linked,'draws':draws,'commands':len(commands),'renderer':gs(0x1F01).decode(),'gl':gs(0x1F02).decode(),'passed':True,'mode':mode,'metrics':metrics}))
