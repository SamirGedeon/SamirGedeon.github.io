/** Record actual engine calls for native GLES validation; no browser or preview. */
import fs from 'node:fs';import vm from 'node:vm';import {resolve} from 'node:path';import {fileURLToPath} from 'node:url';
const project=fileURLToPath(new URL('../../',import.meta.url));const qaDir=resolve(project,'work/gpu-qa');fs.mkdirSync(qaDir,{recursive:true});
const source=fs.readFileSync(resolve(project,'assets/fluid-engine.js'),'utf8');
const mode=process.argv[2]||'full';const trace=[],handles=new Map();let next=0;
const constants={VERTEX_SHADER:35633,FRAGMENT_SHADER:35632,COMPILE_STATUS:35713,LINK_STATUS:35714,ACTIVE_UNIFORMS:35718,MAX_TEXTURE_SIZE:3379,HALF_FLOAT:5131,ARRAY_BUFFER:34962,STATIC_DRAW:35044,FLOAT:5126,TEXTURE_2D:3553,TEXTURE_MIN_FILTER:10241,TEXTURE_MAG_FILTER:10240,TEXTURE_WRAP_S:10242,TEXTURE_WRAP_T:10243,NEAREST:9728,LINEAR:9729,CLAMP_TO_EDGE:33071,FRAMEBUFFER:36160,COLOR_ATTACHMENT0:36064,FRAMEBUFFER_COMPLETE:36053,RGBA16F:34842,RG16F:33327,R16F:33325,RGBA:6408,RG:33319,RED:6403,TEXTURE0:33984,TRIANGLE_STRIP:5,COLOR_BUFFER_BIT:16384,BLEND:3042,ONE:1,ONE_MINUS_SRC_ALPHA:771};
function encode(a){if(a?.id)return {ref:a.id};if(a?.uniform)return {uniform:a.uniform};if(ArrayBuffer.isView(a))return {array:'f32',data:Array.from(a)};return a}
const gl={...constants,getExtension:name=>(mode==='webgl1'&&name.includes('linear'))?null:({HALF_FLOAT_OES:36193}),getParameter:()=>4096,isContextLost:()=>false,getShaderParameter:()=>true,getShaderInfoLog:()=>'',getProgramInfoLog:()=>'',checkFramebufferStatus:()=>36053};
for(const name of ['Shader','Program','Buffer','Texture','Framebuffer'])gl['create'+name]=(...args)=>{const h={id:++next,kind:name};handles.set(h.id,h);trace.push({fn:'create'+name,args,result:h.id});return h};
gl.getProgramParameter=(p,key)=>key===gl.ACTIVE_UNIFORMS?p.uniforms.length:true;
gl.getActiveUniform=(p,i)=>({name:p.uniforms[i]});gl.getUniformLocation=(p,name)=>({uniform:[p.id,name]});
for(const name of ['shaderSource','compileShader','attachShader','bindAttribLocation','linkProgram','deleteShader','useProgram','uniform1i','uniform1f','uniform2f','uniform3f','uniform4fv','bindBuffer','bufferData','enableVertexAttribArray','vertexAttribPointer','bindTexture','texParameteri','texImage2D','bindFramebuffer','framebufferTexture2D','deleteTexture','deleteFramebuffer','deleteBuffer','deleteProgram','activeTexture','viewport','clearColor','clear','disable','enable','drawArrays','blendFunc'])gl[name]=(...args)=>{
 if(name==='shaderSource')args[0].source=args[1];
 if(name==='attachShader')(args[0].shaders??=[]).push(args[1]);
 if(name==='linkProgram')args[0].uniforms=[...new Set(args[0].shaders.flatMap(s=>[...s.source.matchAll(/uniform\s+\w+\s+(\w+)(?:\[(\d+)\])?\s*;/g)].map(m=>m[1]+(m[2]?'[0]':''))))];
 trace.push({fn:name,args:args.map(encode)});
};
const sandbox={window:{},console};vm.runInNewContext(source,sandbox);
const width=800,height=440,canvas={width,height,getContext:name=>name===(mode==='webgl1'?'webgl':'webgl2')?gl:null};
const engine=sandbox.window.SamirFluid.create(canvas,{dyeResolution:mode==='full'?1440:512,onFailure:e=>{throw e}});if(!engine)throw Error('No engine');engine.setSize(width,height,1);
const colors=[[.15,.02,.01],[.02,.15,.01],[.01,.09,.15],[.12,.01,.15],[.15,.01,.08]];
let last={x:90,y:200};
for(let frame=0;frame<(mode==='webgl1'?35:95);frame++){
 if(frame<60){const x=100+frame*10,y=220+110*Math.sin(frame*.105);engine.splat({x,y,dx:x-last.x,dy:y-last.y,color:colors[Math.floor(frame/10)%colors.length]});last={x,y}}
 engine.step(1/60);engine.render({opacity:1,mask:[]});
 if([30,59,94].includes(frame))trace.push({fn:'capture',args:['v8-'+mode+'-'+frame+'.png']});
}
engine.render({opacity:1,mask:[]});trace.push({fn:'capture',args:['v8-'+mode+'-final.png']});
engine.render({opacity:1,mask:[{x:0,y:0,width,height}]});trace.push({fn:'capture',args:['v8-'+mode+'-mask.png']});
engine.render({opacity:.5,mask:[]});trace.push({fn:'capture',args:['v8-'+mode+'-half.png']});
engine.clear();trace.push({fn:'capture',args:['v8-'+mode+'-clear.png']});
fs.writeFileSync(resolve(qaDir,'fluid-v8-'+mode+'-trace.json'),JSON.stringify(trace));
fs.writeFileSync(resolve(qaDir,'fluid-v8-'+mode+'-quality.json'),JSON.stringify({quality:engine.quality,commands:trace.length}));console.log(JSON.stringify({quality:engine.quality,commands:trace.length}));
