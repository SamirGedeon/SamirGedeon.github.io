/** Execute the actual generated Worker handler with native Request/Response APIs. */
import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
import worker from '../dist/server/index.js';import {securityHeaders} from '../scripts/security.mjs';
const root=new URL('../',import.meta.url);let assertions=0;
for(const [path,file] of [['/','index.html'],['/assets/theme-init.js?v=10','assets/theme-init.js'],['/assets/i18n.js','assets/i18n.js'],['/assets/fluid-engine.js','assets/fluid-engine.js'],['/assets/social-card.png','assets/social-card.png'],['/assets/curriculo-samir-gedeon-machado.pdf','assets/curriculo-samir-gedeon-machado.pdf'],['/assets/portfolio-samir.zip','assets/portfolio-samir.zip']]){
 const response=await worker.fetch(new Request('https://portfolio.test'+path));assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),await readFile(new URL(file,root)));assertions+=2;
 for(const [name,value] of Object.entries(securityHeaders)){assert.equal(response.headers.get(name),value);assertions++;}
 const etag=response.headers.get('etag');assert.ok(etag);const cached=await worker.fetch(new Request('https://portfolio.test'+path,{headers:{'If-None-Match':etag}}));assert.equal(cached.status,304);assert.equal((await cached.arrayBuffer()).byteLength,0);assertions+=3;
 const head=await worker.fetch(new Request('https://portfolio.test'+path,{method:'HEAD'}));assert.equal(head.status,200);assert.equal((await head.arrayBuffer()).byteLength,0);assertions+=2;
}
for(const path of ['/.env','/.git/config','/.openai/hosting.json','/scripts/security.mjs','/_headers','/server/index.js','/assets/..%2f..%2f.env','/%E0%A4%A']){const response=await worker.fetch(new Request('https://portfolio.test'+path));assert.equal(response.status,404);assertions++;}
for(const method of ['POST','PUT','DELETE','PATCH']){const response=await worker.fetch(new Request('https://portfolio.test/',{method}));assert.equal(response.status,405);assert.equal(response.headers.get('Allow'),'GET, HEAD');assertions+=2;}
console.log('PASS Worker: '+assertions+' assertions; security headers, exact public assets, cache, HEAD and private-route/write rejection.');
