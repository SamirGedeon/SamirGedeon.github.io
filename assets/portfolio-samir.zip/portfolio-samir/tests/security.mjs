/** Security-policy and public-artifact regression checks. */
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {contentSecurityPolicy,securityHeaders} from '../scripts/security.mjs';
const root=new URL('../',import.meta.url),html=await readFile(new URL('index.html',root),'utf8');
const policy=html.match(/<meta http-equiv="Content-Security-Policy" content="([^"]+)"/)?.[1];
assert.equal(policy,contentSecurityPolicy,'browser meta policy and server policy use the same baseline');
assert.ok(policy.includes("script-src 'self'"));assert.ok(!policy.includes('unsafe-eval'));assert.ok(!policy.includes("script-src 'self' 'unsafe-inline'"));
assert.ok(policy.includes("connect-src 'none'"));assert.ok(policy.includes("object-src 'none'"));assert.ok(policy.includes("base-uri 'none'"));assert.ok(policy.includes("form-action 'none'"));
const scriptTags=[...html.matchAll(/<script\b[^>]*>/g)];
assert.ok(scriptTags.length>0);
for(const match of scriptTags){
 const src=match[0].match(/\bsrc="([^"]+)"/)?.[1];assert.ok(src,'no inline script');
 assert.equal(new URL(src,'https://portfolio.test/').origin,'https://portfolio.test','all executable scripts are local external files');
}
assert.ok(!/\son[a-z]+\s*=/i.test(html),'no inline event handlers');
assert.ok(html.includes('name="referrer" content="strict-origin-when-cross-origin"'));
const headers=await readFile(new URL('dist/_headers',root),'utf8');for(const [name,value]of Object.entries(securityHeaders))assert.ok(headers.includes(`${name}: ${value}`),name);
assert.ok(html.includes('property="og:image"'));const png=await readFile(new URL('assets/social-card.png',root));assert.equal(png.readUInt32BE(16),1200);assert.equal(png.readUInt32BE(20),630);
const ignores=await readFile(new URL('.gitignore',root),'utf8');for(const rule of ['.env','*.pem','*.key','credentials*.json'])assert.ok(ignores.includes(rule),rule);
for(const file of ['app.js','assets/i18n.js','assets/theme-init.js','assets/fluid-engine.js']){
 const source=await readFile(new URL(file,root),'utf8');assert.ok(!/\beval\s*\(|new\s+Function\s*\(|document\.write\s*\(/.test(source),file+' must not execute JavaScript strings');
}
console.log('PASS security: CSP, local scripts, safe browser policies, share image and secret ignore rules');
