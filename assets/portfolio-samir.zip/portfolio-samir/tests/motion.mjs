/** Scroll-reveal lifecycle tests with an observer stub; these do not render CSS. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const source=readFileSync(new URL('../app.js',import.meta.url),'utf8');
const start=source.indexOf('function setupScrollReveals() {');
const end=source.indexOf('\nmotionListeners.push(setupScrollReveals());',start);
assert.ok(start>=0&&end>start);
const setup=source.slice(start,end);
let passed=0;
function test(name,run){run();passed++;console.log('PASS',name)}
function fixture(withObserver=true){
 const observers=[];
 let enabled=true;
 const make=(top,project=false)=>{
  const classes=new Set(project?['project-card']:[]),styles=new Map();
  return {classes,styles,top,classList:{add:c=>classes.add(c),remove:c=>classes.delete(c),contains:c=>classes.has(c)},style:{setProperty:(k,v)=>styles.set(k,v)},getBoundingClientRect(){return {top:this.top}}};
 };
 const items=[make(80),make(1200,true),make(1800)];
 const context={document:{querySelectorAll:()=>items},cards:[items[1]],innerHeight:800,motionAllowed:()=>enabled};
 if(withObserver)context.IntersectionObserver=class{
  targets=new Set();
  constructor(callback){this.callback=callback;observers.push(this)}
  observe(item){this.targets.add(item)}
  unobserve(item){this.targets.delete(item)}
  disconnect(){this.targets.clear()}
  enter(item){this.callback([{target:item,isIntersecting:true}])}
 };
 const refresh=vm.runInNewContext(`(${setup})()`,context);
 return {items,observers,refresh,disable(){enabled=false;refresh()},enable(){enabled=true;refresh()}};
}
test('only content below the viewport waits for a scroll entrance',()=>{
 const app=fixture();
 assert.equal(app.items[0].classes.has('reveal-pending'),false);
 for(const item of app.items.slice(1))assert.equal(item.classes.has('reveal-pending'),true);
 assert.equal(app.observers[0].targets.size,2);
});
test('entering content is revealed once and stops being observed',()=>{
 const app=fixture(),item=app.items[1];
 app.observers[0].enter(item);
 assert.equal(item.classes.has('reveal-pending'),false);
 assert.equal(app.observers[0].targets.has(item),false);
 item.top=2200;app.refresh();
 assert.equal(item.classes.has('reveal-pending'),false,'previously seen content stays readable after refresh');
 assert.equal(app.observers.at(-1).targets.has(item),false);
});
test('disabling movement immediately reveals pending content and disconnects the observer',()=>{
 const app=fixture();app.disable();
 assert.ok(app.items.every(item=>!item.classes.has('reveal-pending')));
 assert.equal(app.observers[0].targets.size,0);
 app.enable();
 assert.equal(app.observers.at(-1).targets.size,2,'unseen content may animate if the visitor enables movement');
});
test('missing IntersectionObserver leaves all content directly available',()=>{
 const app=fixture(false);assert.equal(typeof app.refresh,'function');app.refresh();
 assert.ok(app.items.every(item=>!item.classes.has('reveal-pending')));
 assert.equal(app.observers.length,0);
});
console.log(`${passed} scroll lifecycle tests passed with observer stubs. No browser validation performed.`);
