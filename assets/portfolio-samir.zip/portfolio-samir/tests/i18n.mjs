/** Language behavior using actual i18n.js and app.js in an emulated DOM; no browser rendering. */
import assert from 'node:assert/strict';
import {fixture} from './dom-fixture.mjs';
let passed=0;
function test(name,run){run();passed++;console.log('PASS',name)}
test('all three languages translate source text and accessibility without replacing child icons',()=>{
 const e=fixture({i18n:true});const i=e.i18n;assert.equal(i.language,'pt');assert.equal(e.document.documentElement.getAttribute('lang'),'pt-BR');
 const children=[...e.q('.header-cv').childNodes];
 i.setLanguage('en');assert.equal(e.document.documentElement.getAttribute('lang'),'en');
 assert.equal(e.texts.get('#hero-title').nodeValue,'DEVELOPMENT');
 assert.match(e.texts.get('.readme-facts').nodeValue,/Basic English/);assert.match(e.texts.get('.header-cv').nodeValue,/PT-BR/);
 assert.match(e.q('.header-cv').getAttribute('aria-label'),/Download.*PDF.*PT-BR/);
 assert.ok(children.every((child,index)=>e.q('.header-cv').childNodes[index]===child));
 assert.equal(e.texts.get('unchanged-code').nodeValue,'DESENVOLVER');
 assert.equal(e.texts.get('[data-translate-code]').nodeValue,'"basic"');
 i.setLanguage('es');assert.equal(e.document.documentElement.getAttribute('lang'),'es');assert.match(e.texts.get('.readme-facts').nodeValue,/Inglés básico/);
 i.setLanguage('pt');assert.equal(e.texts.get('#hero-title').nodeValue,'DESENVOLVER');assert.equal(e.texts.get('[data-translate-code]').nodeValue,'"básico"');
});
test('valid stored choice restores, invalid/prototype values fall back to Portuguese',()=>{
 const saved=fixture({i18n:true,savedLanguage:'es'});assert.equal(saved.i18n.language,'es');assert.equal(saved.q('#language-code').textContent,'ES');
 for(const value of ['fr','__proto__','toString'])assert.equal(fixture({i18n:true,savedLanguage:value}).i18n.language,'pt');
 assert.equal(saved.i18n.setLanguage('fr'),false);assert.equal(saved.i18n.language,'es');
});
test('language preferences persist and remain usable with blocked localStorage',()=>{
 const e=fixture({i18n:true});e.i18n.setLanguage('en');assert.equal(e.storage.get('samir-language'),'en');
 const blocked=fixture({i18n:true,storageBlocked:true});assert.doesNotThrow(()=>blocked.i18n.setLanguage('es'));assert.equal(blocked.i18n.language,'es');
});
test('dropdown supports selection, keyboard navigation, Escape and outside click',()=>{
 const e=fixture({i18n:true});const toggle=e.q('#language-toggle'),menu=e.q('#language-menu');
 assert.equal(e.q('#language-control').hidden,false);toggle.click();assert.equal(menu.hidden,false);assert.equal(toggle.getAttribute('aria-expanded'),'true');
 e.key(toggle,'ArrowDown');assert.equal(e.document.activeElement.dataset.language,'pt');
 e.key(e.document.activeElement,'End');assert.equal(e.document.activeElement.dataset.language,'en');
 e.document.activeElement.click();assert.equal(e.i18n.language,'en');assert.equal(menu.hidden,true);assert.equal(e.document.activeElement,toggle);
 toggle.click();e.key(toggle,'Escape');assert.equal(menu.hidden,true);assert.equal(e.document.activeElement,toggle);
 toggle.click();e.q('.header-cv').click();assert.equal(menu.hidden,true);assert.equal(toggle.getAttribute('aria-expanded'),'false');
 toggle.click();e.q('.header-cv').focus();e.document.emit('focusin',{target:e.q('.header-cv')});assert.equal(menu.hidden,true);assert.equal(e.document.activeElement,e.q('.header-cv'));
});
test('switching languages preserves project filter, open modal, editor files and selected technology',()=>{
 const e=fixture({i18n:true});e.qa('[data-filter]').find(b=>b.dataset.filter==='web').click();
 e.q('#tab-estudos').click();e.qa('[data-close-file]').find(b=>b.dataset.closeFile==='sobre').click();
 e.qa('[data-tech]').find(b=>b.dataset.tech==='python').click();e.qa('[data-preview]').find(b=>b.dataset.preview==='fruta').click();
 e.i18n.setLanguage('en');
 assert.equal(e.qa('.project-card').filter(card=>!card.hidden).length,2);assert.equal(e.q('#filter-status').textContent,'2 projects shown.');
 assert.equal(e.q('#tab-sobre').hidden,true);assert.equal(e.q('#panel-estudos').hidden,false);assert.equal(e.q('#project-dialog').open,true);
 assert.equal(e.q('#tecnologias').dataset.activeTech,'python');assert.match(e.q('#tech-detail-copy').textContent,/Python/);assert.match(e.q('#tech-detail-copy').textContent,/JSON/);
 assert.match(e.q('#preview-image').alt,/Fruta/);assert.equal(e.document.documentElement.dataset.theme,'light');
});
test('dynamic labels and same-language selection retain correct dark-theme actions',()=>{
 const e=fixture({i18n:true});e.q('#theme-toggle').click();e.i18n.setLanguage('pt');
 assert.equal(e.q('#theme-toggle').getAttribute('aria-label'),'Ativar modo claro');
 e.i18n.setLanguage('en');assert.match(e.q('#theme-toggle').getAttribute('aria-label'),/light mode/);
 e.i18n.setLanguage('en');assert.match(e.q('#theme-toggle').getAttribute('aria-label'),/light mode/);
 e.q('#motion-toggle').click();assert.equal(e.q('#motion-label').textContent,'Enable motion');
 e.q('#portrait-slider').value=25;e.q('#portrait-slider').emit('input');assert.match(e.q('#portrait-slider').getAttribute('aria-valuetext'),/25% design/);
});
test('language changes keep the editor empty and translate close announcements without reopening files',()=>{
 const e=fixture({i18n:true});e.qa('[data-close-file]').forEach(button=>button.click());
 e.i18n.setLanguage('es');assert.equal(e.q('#editor-empty').hidden,false);assert.ok(e.qa('[data-editor]').every(tab=>tab.hidden));
 assert.match(e.q('#editor-announcement').textContent,/cerrado/);assert.equal(e.q('#editor-locale').textContent,'ES');
 e.i18n.setLanguage('en');assert.match(e.q('#editor-announcement').textContent,/closed/);assert.equal(e.q('#editor-locale').textContent,'EN');
});
console.log(`${passed} localization tests passed with actual dictionaries and emulated DOM. No browser validation performed.`);
