/** HTTP regression tests against real child servers; no browser is used. */
import assert from 'node:assert/strict';
import {securityHeaders} from '../scripts/security.mjs';
import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const project = resolve(fileURLToPath(new URL('../', import.meta.url)));
const files = [
  ['/', 'index.html', 'text/html; charset=utf-8'],
  ['/styles.css', 'styles.css', 'text/css; charset=utf-8'],
  ['/app.js', 'app.js', 'text/javascript; charset=utf-8'],
  ['/assets/fluid-engine.js', 'assets/fluid-engine.js', 'text/javascript; charset=utf-8'],
  ['/assets/i18n.js', 'assets/i18n.js', 'text/javascript; charset=utf-8'],
  ['/assets/theme-init.js', 'assets/theme-init.js', 'text/javascript; charset=utf-8'],
  ['/assets/social-card.png', 'assets/social-card.png', 'image/png'],
  ['/assets/vendor/fluid-LICENSE.txt', 'assets/vendor/fluid-LICENSE.txt', 'text/plain; charset=utf-8'],
  ['/assets/portfolio-samir.zip', 'assets/portfolio-samir.zip', 'application/zip'],
  ['/assets/portrait-cutout.webp', 'assets/portrait-cutout.webp', 'image/webp'],
  ['/assets/portrait-art.webp', 'assets/portrait-art.webp', 'image/webp'],
  ['/assets/portrait-art-full.webp', 'assets/portrait-art-full.webp', 'image/webp'],
  ['/assets/paper-grain.svg', 'assets/paper-grain.svg', 'image/svg+xml'],
  ['/assets/paper-grain.png', 'assets/paper-grain.png', 'image/png'],
  ['/assets/icons/markdown.svg', 'assets/icons/markdown.svg', 'image/svg+xml'],
  ['/assets/icons/json.svg', 'assets/icons/json.svg', 'image/svg+xml'],
  ['/assets/icons/javascript.svg', 'assets/icons/javascript.svg', 'image/svg+xml'],
  ['/assets/icons/pdf.svg', 'assets/icons/pdf.svg', 'image/svg+xml'],
  ['/assets/icons/java.svg', 'assets/icons/java.svg', 'image/svg+xml'],
  ['/assets/icons/spring.svg', 'assets/icons/spring.svg', 'image/svg+xml'],
  ['/assets/icons/python.svg', 'assets/icons/python.svg', 'image/svg+xml'],
  ['/assets/icons/django.svg', 'assets/icons/django.svg', 'image/svg+xml'],
  ['/assets/icons/database.svg', 'assets/icons/database.svg', 'image/svg+xml'],
  ['/assets/icons/html.svg', 'assets/icons/html.svg', 'image/svg+xml'],
  ['/assets/icons/css.svg', 'assets/icons/css.svg', 'image/svg+xml'],
  ['/assets/portrait.jpg', 'assets/portrait.jpg', 'image/jpeg'],
  ['/assets/fonts/archivo.woff2', 'assets/fonts/archivo.woff2', 'font/woff2'],
  ['/assets/curriculo-samir-gedeon-machado.pdf', 'assets/curriculo-samir-gedeon-machado.pdf', 'application/pdf'],
  ['/assets/lab.svg', 'assets/lab.svg', 'image/svg+xml'],
  ['/assets/fonts/syne-1.ttf', 'assets/fonts/syne-1.ttf', 'font/ttf'],
  ['/assets/projects/drew.png', 'assets/projects/drew.png', 'image/png'],
];
let assertions = 0;

async function checkMode(dist) {
  const label = dist ? 'dist' : 'dev';
  const directory = dist ? resolve(project, 'dist') : project;
  const child = spawn(process.execPath, [resolve(project, 'scripts/serve.mjs'), ...(dist ? ['--dist'] : [])], {
    cwd: project,
    env: { ...process.env, PORT: '0', HOST: '127.0.0.1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stdout = '';
  let stderr = '';
  let startupTimer;
  let closed = false;
  const stopped = new Promise(done => child.once('close', () => { closed = true; done(); }));
  child.stderr.on('data', chunk => { stderr += chunk; });
  try {
    const base = await new Promise((done, fail) => {
      startupTimer = setTimeout(() => fail(new Error(`${label}: server did not print a URL. ${stderr}`)), 10_000);
      child.once('error', fail);
      child.once('exit', code => fail(new Error(`${label}: server exited before startup (${code}). ${stderr}`)));
      child.stdout.on('data', chunk => {
        stdout += chunk;
        const match = stdout.match(/http:\/\/127\.0\.0\.1:(\d+)/);
        if (match) {
          assert.notEqual(Number(match[1]), 0, `${label}: log must show the actual assigned port`);
          done(match[0]);
        }
      });
    });
    clearTimeout(startupTimer);
    const request = (path, options = {}) => fetch(`${base}${path}`, { signal: AbortSignal.timeout(5_000), ...options });
    const root = await readFile(resolve(directory, 'index.html'));
    async function assertPolicies(response) {
      for (const [name,value] of Object.entries(securityHeaders)) { assert.equal(response.headers.get(name),value,`${label}: ${name}`); assertions++; }
    }
    for (const [path, file, mime] of files) {
      const response = await request(path);
      await assertPolicies(response);
      assert.equal(response.status, 200, `${label}: GET ${path}`);
      assert.equal(response.headers.get('content-type'), mime, `${label}: MIME ${path}`);
      const expected = await readFile(resolve(directory, file));
      const received = Buffer.from(await response.arrayBuffer());
      assert.deepEqual(received, expected, `${label}: response must contain the real file at ${path}`);
      assert.equal(Number(response.headers.get('content-length')), expected.length, `${label}: length ${path}`);
      assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
      assertions += 5;
    }
    const head = await request('/', { method: 'HEAD' });
    await assertPolicies(head);
    assert.equal(head.status, 200, `${label}: HEAD /`);
    assert.equal(head.headers.get('content-type'), 'text/html; charset=utf-8');
    assert.equal(Number(head.headers.get('content-length')), root.length);
    assert.equal((await head.arrayBuffer()).byteLength, 0, `${label}: HEAD must have no body`);
    assertions += 4;
    for (const path of [
      '/README.md',
      '/.env',
      '/.git/config',
      '/.openai/hosting.json',
      '/_headers',
      '/work/check-interactions.mjs',
      '/tests/server.mjs',
      // Encoded separators survive fetch's URL normalization and must not
      // let an assets-prefixed request expose a private file after decoding.
      '/assets/..%2fREADME.md',
      '/assets/..%2ftests%2fserver.mjs',
      '/assets/%2e%2e%2fREADME.md',
      // Traversal beyond the served directory must also remain blocked.
      '/assets/..%2f..%2fetc%2fpasswd',
      '/assets/%2e%2e%2f%2e%2e%2fREADME.md',
      '/assets/..%5c..%5cREADME.md',
    ]) {
      const response = await request(path);
      await assertPolicies(response);
      assert.equal(response.status, 404, `${label}: private source route ${path}`);
      await response.arrayBuffer();
      assertions++;
    }
    const post = await request('/', { method: 'POST' });
    await assertPolicies(post);
    assert.equal(post.status, 405, `${label}: POST /`);
    assert.equal(post.headers.get('allow'), 'GET, HEAD');
    await post.arrayBuffer();
    assertions += 2;
    console.log(`PASS HTTP ${label}: HTML, CSS, JS, SVG, font, PNG, MIME, HEAD, source access and POST`);
  } finally {
    clearTimeout(startupTimer);
    if (!closed) child.kill('SIGTERM');
    const killTimer = setTimeout(() => { if (!closed) child.kill('SIGKILL'); }, 2_000);
    try { await stopped; } finally { clearTimeout(killTimer); }
  }
}

await checkMode(false);
await checkMode(true);
console.log(`${assertions} HTTP assertions passed. Both child servers stopped. No browser validation performed.`);
