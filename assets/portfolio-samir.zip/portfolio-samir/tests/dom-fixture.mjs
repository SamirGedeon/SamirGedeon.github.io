/**
 * Logic tests for the actual app.js in an emulated, deliberately small DOM.
 * This is NOT a browser test: no layout, native dialog behavior, accessibility
 * tree, keyboard default actions, pointer hit testing, or CSS is simulated.
 */
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const source = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
const languageSource = readFileSync(new URL('../assets/i18n.js', import.meta.url), 'utf8');

class Events {
  handlers = new Map();
  addEventListener(type, fn) {
    const handlers = this.handlers.get(type) ?? [];
    handlers.push(fn);
    this.handlers.set(type, handlers);
  }
  emit(type, event = {}) {
    for (const fn of this.handlers.get(type) ?? []) fn({ type, ...event });
  }
}

export function fixture(options = {}) {
  const all = [];
  const document = new Events();
  document.hidden = false;
  document.activeElement = null;
  class Element extends Events {
    constructor(tagName, attrs, parent) {
      super();
      this.tagName = tagName;
      this.attrs = attrs;
      this.parentElement = parent;
      this.dataset = Object.fromEntries(Object.entries(attrs).filter(([k]) => k.startsWith('data-')).map(([k, v]) => [k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase()), v]));
      this.hidden = 'hidden' in attrs;
      this.disabled = 'disabled' in attrs;
      this.textContent = '';
      this.childNodes = [];
      this.nodeType = 1;
      this.styles = new Map();
      this.style = {
        setProperty: (k, v) => this.styles.set(k, v),
        removeProperty: k => this.styles.delete(k),
      };
      this.classList = {
        contains: k => (this.attrs.class ?? '').split(/\s+/).includes(k),
        add: k => this.classList.toggle(k, true),
        remove: k => this.classList.toggle(k, false),
        toggle: (k, force) => {
          const names = new Set((this.attrs.class ?? '').split(/\s+/).filter(Boolean));
          const present = force ?? !names.has(k);
          present ? names.add(k) : names.delete(k);
          this.attrs.class = [...names].join(' ');
          return present;
        },
      };
      this.scrolls = [];
      if (tagName === 'dialog' && options.dialogSupported !== false) {
        this.showModal = () => { this.open = true; };
        this.close = () => { this.open = false; this.emit('close', { target: this }); };
      }
    }
    matches(selector) {
      if (selector.includes(',')) return selector.split(',').some(item => this.matches(item.trim()));
      if (selector === 'a[href^="#"]') return this.tagName === 'a' && (this.attrs.href ?? '').startsWith('#');
      const attribute = selector.match(/^([\w-]+)?\[([^=\]]+)(?:=["']?([^"'\]]+)["']?)?\]$/);
      if (attribute) return (!attribute[1] || this.tagName === attribute[1]) && attribute[2] in this.attrs && (attribute[3] === undefined || this.attrs[attribute[2]] === attribute[3]);
      if (selector.startsWith('#')) return this.attrs.id === selector.slice(1);
      if (selector.startsWith('.')) return this.classList.contains(selector.slice(1));
      if (/^[\w-]+$/.test(selector)) return this.tagName === selector;
      throw new Error(`Unsupported selector in test fixture: ${selector}`);
    }
    closest(selector) {
      for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node;
      return null;
    }
    setAttribute(k, value) { this.attrs[k] = String(value); }
    removeAttribute(k) { delete this.attrs[k]; }
    get id() { return this.attrs.id ?? ''; }
    get value() { return this.attrs.value ?? ''; }
    set value(value) { this.attrs.value = String(value); }
    get tabIndex() { return Number(this.attrs.tabindex ?? (this.tagName === 'button' ? 0 : -1)); }
    set tabIndex(value) { this.attrs.tabindex = String(value); }
    querySelectorAll(selector) { return all.filter(node => { for (let parent = node.parentElement; parent; parent = parent.parentElement) if (parent === this) return node.matches(selector); return false; }); }
    querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null; }
    getAttribute(k) { return this.attrs[k] ?? null; }
    hasAttribute(k) { return k in this.attrs; }
    get href() { return this.attrs.href; }
    set href(value) { this.attrs.href = value; }
    focus() { document.activeElement = this; }
    getBoundingClientRect() { return { left: 0, top: 0, right: 800, bottom: 650, width: 800, height: 650 }; }
    scrollIntoView(options) { this.scrolls.push(options); }
    click() {
      if (this.disabled) return;
      const event = { target: this, clientX: 10, clientY: 10, preventDefault() { this.defaultPrevented = true; } };
      for (let node = this; node; node = node.parentElement) node.emit('click', event);
      document.emit('click', event);
    }
  }
  const stack = [];
  const voids = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  for (const token of html.matchAll(/<!--[\s\S]*?-->|<![^>]*>|<\/?[^>]+>/g)) {
    const text = token[0];
    if (text.startsWith('<!')) continue;
    const closing = /^<\//.test(text);
    const tag = text.match(/^<\/?([\w-]+)/)?.[1]?.toLowerCase();
    if (!tag) continue;
    if (closing) {
      const at = stack.findLastIndex(el => el.tagName === tag);
      if (at >= 0) stack.length = at;
      continue;
    }
    const attrs = {};
    const rest = text.slice(text.indexOf(tag) + tag.length, -1);
    for (const attr of rest.matchAll(/([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) attrs[attr[1]] = attr[2] ?? attr[3] ?? attr[4] ?? '';
    const node = new Element(tag, attrs, stack.at(-1) ?? null);
    all.push(node);
    node.parentElement?.childNodes.push(node);
    if (!voids.has(tag) && !text.endsWith('/>')) stack.push(node);
  }
  document.querySelectorAll = selector => all.filter(node => node.matches(selector));
  document.querySelector = selector => document.querySelectorAll(selector)[0] ?? null;
  document.getElementById = id => all.find(node => node.attrs.id === id) ?? null;
  document.documentElement = document.querySelector('#missing-html') ?? all.find(node => node.tagName === 'html');
  document.body = all.find(node => node.tagName === 'body');
  const texts = new Map();
  function sample(selector, value, name = selector) {
    const parent = document.querySelector(selector);
    const node = {nodeType:3,nodeValue:value,parentElement:parent};
    parent.childNodes.push(node);texts.set(name,node);return node;
  }
  if (options.i18n) {
    sample('#hero-title','DESENVOLVER');
    sample('.readme-facts','Português · Inglês básico');
    sample('.header-cv','Baixar currículo');
    sample('[data-translate-code]','"básico"');
    sample('pre','DESENVOLVER','unchanged-code');
  }
  const windowEvents = new Events();
  const motion = new Events(); motion.matches = Boolean(options.reduce);
  const compact = new Events(); compact.matches = Boolean(options.compact);
  const scheme = new Events(); scheme.matches = Boolean(options.dark);
  const storage = new Map(options.savedMotion ? [['samir-motion', options.savedMotion]] : []);
  if (options.savedTheme) storage.set('samir-theme', options.savedTheme);
  if (options.savedLanguage) storage.set('samir-language', options.savedLanguage);
  const frames = new Map(); let frameId = 0;
  const location = { hash: '' };
  const sandbox = {
    document, location, window: windowEvents, innerWidth: 1280, innerHeight: 800,
    navigator: { connection: { saveData: Boolean(options.saveData) }, deviceMemory: options.memory ?? 8, hardwareConcurrency: options.cores ?? 8 },
    matchMedia: query => query.includes('prefers-reduced-motion') ? motion : query.includes('prefers-color-scheme') ? scheme : compact,
    localStorage: {
      getItem: key => { if (options.storageBlocked) throw new Error('Storage blocked'); return storage.get(key) ?? null; },
      setItem: (key, value) => { if (options.storageBlocked) throw new Error('Storage blocked'); storage.set(key, value); },
    },
    requestAnimationFrame: callback => { const id = ++frameId; frames.set(id, callback); return id; },
    cancelAnimationFrame: id => frames.delete(id),
    addEventListener: windowEvents.addEventListener.bind(windowEvents),
  };
  if (options.i18n) runInNewContext(languageSource, sandbox, { filename:'i18n.js' });
  runInNewContext(source, sandbox, { filename: 'app.js' });
  return {
    document, all, motion, compact, scheme, location, storage, frames, texts,
    i18n: windowEvents.SamirI18n,
    q: selector => document.querySelector(selector),
    qa: selector => document.querySelectorAll(selector),
    key: (target,key) => { const event={key,target,preventDefault(){this.defaultPrevented=true}}; for(let node=target;node;node=node.parentElement) node.emit('keydown',event);document.emit('keydown',event); },
    setHash: hash => { location.hash = hash; windowEvents.emit('hashchange'); },
    makeAnchor: hash => { const anchor = new Element('a', { href: hash }, document.body); const child = new Element('span', {}, anchor); all.push(anchor, child); return { anchor, child }; },
    flush: () => { const pending = [...frames.values()]; frames.clear(); pending.forEach(fn => fn()); },
  };
}

