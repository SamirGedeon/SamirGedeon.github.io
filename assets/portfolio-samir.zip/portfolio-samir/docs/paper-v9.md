# Papel do tema claro — nona versão

A referência https://majd-portfolio.framer.website/ foi aberta novamente pela ferramenta web e seu HTML público retornou HTTP 200. A base clara confirmada é `rgb(250, 247, 243)` (`#faf7f3`), a mesma cor que o portfólio já usava. O material entregue aplica uma imagem de ruído repetida com `background-size: 161px` e opacidade `0.04`. Essa textura, e não uma nova paleta, é a diferença visual relevante.

Nenhum asset ou código do template foi copiado. `assets/paper-grain.png` é um PNG original de 192 × 192 pixels, gerado de forma determinística com a semente `0x53474D09`. Usa quatro níveis monocromáticos (0, 85, 170 e 255), distribuídos com probabilidades 14%, 36%, 36% e 14%, e alfa constante de 10/255, aproximadamente 3,92%. O arquivo tem 8933 bytes. A transparência já está no PNG: os fundos não precisam de uma segunda opacidade que tornaria o grão novamente imperceptível.

O padrão repete a cada 161 pixels CSS. É estático, sem filtros animados nem dependências. A aplicação foi limitada às camadas de pintura do fundo: corpo, composição do retrato, barra superior e controles do retrato. O pseudo-elemento anterior é desativado apenas no tema claro para evitar duas camadas de ruído. As superfícies opacas do retrato também recebem o padrão, evitando uma área lisa no meio da página.

O ruído fica atrás dos conteúdos; não existe overlay acima das fotografias, capturas de projetos, editor ou canvas WebGL. O contato continua com superfície branca limpa, para preservar a composição transparente do fluido. As regras do tema escuro não foram alteradas.

Foi conferida a estrutura do PNG, os limites de cor/alfa e seu tamanho. Uma amostra matemática do fundo composto foi gerada e inspecionada em `work/paper-v9-preview.png`; ela não é captura da página. Não foi realizada validação visual em navegador nesta tarefa, pois a ferramenta de prévia/CUA não está disponível. A validação integrada dos assets e da página será executada pelo agente principal.
