# Rastro vetorial e bancada conectada — sétima versão

## Referência e decisão

A URL https://www.aaabadcode.com/ foi aberta novamente pela ferramenta web e seu HTML/bundle público retornou HTTP200. O material confirma uma simulação WebGL com campos de velocidade e pigmento separados, usando uma resolução de pigmento maior. Isso ajuda a explicar a diferença em relação à textura de grade pequena que nosso efeito anterior ampliava. Não foi possível interagir com a referência em um navegador nesta rodada. Nenhum código, shader, imagem ou identidade do site foi incorporado ao portfólio.

A implementação do portfólio permanece própria e sem novas dependências: fitas curvas Canvas2D na resolução do canvas, com DPR até2 e orçamento de4MP. Não é uma reprodução da simulação física WebGL da referência. As curvas nativas eliminam a ampliação da grade antiga.

## Alterações

O traço nasce fino e ganha largura ao longo de algumas centenas de milissegundos. Cinco faixas de cor recebem curvatura e suavização local das bordas; não existe blur global da tela. Movimentos rápidos são conectados por curvas, e coordenadas repetidas não reiniciam o efeito. Uma máscara arredondada protege os textos. O desenho encerra após1400ms sem novo gesto e não deixa um loop JavaScript em repouso. Movimento reduzido, telas compactas, dispositivos restritos, aba oculta e saída da seção continuam interrompendo o rastro.

Na bancada, uma conexão SVG liga o núcleo à tecnologia ativa, o núcleo mostra seu nome e o cartão selecionado ganha altura. O mouse altera a perspectiva em poucos graus; o painel de informações recebe uma transição curta. Cartões flutuam apenas5px enquanto a bancada está visível. As animações CSS param ao sair da área visível; celulares e preferências reduzidas mantêm a grade estática. Seleção, textos factuais e links reais permanecem operáveis.

Os cartões agora usam logos oficiais de Java, Spring, Python, Django, banco de dados, HTML, CSS e JavaScript. SVGs e licenças são locais, com origem registrada em docs/icones.md. O ícone de banco de dados representa a categoria SQL/MySQL e não muda as tecnologias confirmadas de nenhum projeto.

## Verificações e limite

Passaram a verificação estática,26 testes de interação em DOM emulado,8 testes de desenho e ciclo de vida Canvas2D com stubs,4 testes das entradas com stubs IntersectionObserver e280 asserções HTTP nos modos dev/dist. Os testes do rastro verificam desenho vetorial, crescimento da largura com a idade, continuidade, coordenadas repetidas, proteção de texto e cancelamento. Os testes de bancada conferem seleção, conexão, nome central, parallax e redução de movimento.

Não foi realizada validação visual em navegador nesta rodada: o ambiente não disponibiliza a ferramenta de prévia/CUA. Os testes confirmam lógica e respostas HTTP, mas não aparência final, percepção de fluidez, composição responsiva, gestos nativos ou igualdade visual com a referência. Capturas de versões anteriores não validam esta atualização.
