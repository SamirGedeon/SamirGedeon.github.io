# Verificações — 10/11/2026

## Concluídas

- `npm run check`: sintaxe de todos os arquivos JavaScript, 27 IDs únicos, âncoras, assets locais, referências ARIA, imagens com alt, proteção de links externos e quatro links de repositórios presentes.
- `npm test`: 11 casos passaram executando o `app.js` real num DOM mínimo emulado por `node:vm`, sem bibliotecas. Cobrem ativação progressiva dos controles; seleção das três estações; filtros e contagens; projeto oculto com hash repetido, inclusive clique no ícone filho; hashchange e URI inválida; movimento reduzido do SO sobrepondo preferência salva; persistência e cancelamento de frame; reset ao ocultar aba; ausência de tilt em celular/toque/economia de dados/pouca memória/poucos núcleos; callbacks do diálogo e foco; fallback sem diálogo e sem armazenamento local.
- `npm run build`: gerado `dist/`, com cerca de 1 MB incluindo as três capturas. Não há dependências de produção nem chamada de rede em tempo de execução.
- Parser HTML: 278 elementos com tags balanceadas e sem atributos duplicados. Os dois SVGs foram validados como XML.
- Três PNGs originais verificados com dimensões 1200 × 800. O código Python exibido é um trecho exato da evidência em `docs/projects.json`.
- A ilustração SVG foi rasterizada para inspeção com uma ferramenta de desenvolvimento temporária (`@resvg/resvg-js`, mantida somente em `work/`). Não foi renderizada a página HTML.
- Contraste calculado em pares principais de texto: secundário escuro 7,49:1; dica do laboratório 5,02:1; legenda clara 5,74:1; metadados de projeto 4,74:1; nota de projetos 5,00:1; texto sobre verde 15,02:1. Não é uma auditoria integral de acessibilidade.
- Largura da palavra principal estimada com as métricas da fonte TTF em 320, 375, 768, 900, 901 e 1024 px, após ajuste do breakpoint e tamanho mínimo. Isso verifica a estimativa tipográfica, não o layout renderizado.
- Revisão factual por leitura de código/README e perfil público. Nenhuma demo pública foi encontrada. Tecnologias e resumos foram limitados ao confirmado.

## Problemas corrigidos

- Link de estação para projeto oculto depois de um filtro, mesmo quando o hash do endereço já coincide com o destino.
- Possível transbordamento do título em 320 px e em tablets de duas colunas. Hero agora empilha até 900 px.
- Descrição alternativa da captura do Drew Studio ajustada à imagem real.
- Comentário ilustrativo removido de trecho apresentado como código real.
- Botão de ação de movimento sem semântica conflitante de toggle; filtros e estações com grupo acessível.
- Cor de uma nota em fundo claro escurecida após medição de contraste.

## Ainda não verificado em navegador

Esta sessão não expôs `cua_repl.js` nem outro controle de desktop. O ambiente selecionado é `ccarenv_b64_Y2NhcmVudl9jNGI0OGNiMDlmOTg4MTkxOGFkNWY5MmMyNDVhYWJjZA`; o status retornou ambiente conectado e desktop habilitado, com estado de desktop `unknown`. A skill Sites, em perfil managed Linux, determina pular o preview e não substituir o controle ausente por outro navegador.

A infraestrutura integrada de preview não iniciou; nenhum navegador alternativo foi usado. Posteriormente foi iniciado o servidor Node como diagnóstico de inicialização e verificado por HTTP, sem gerar URL externa. Layout completo, animação renderizada, toque, ordem real de Tab, comportamento nativo do diálogo e leitor de tela **permanecem pendentes de verificação manual**. Os testes de DOM emulado e de HTTP não comprovam essas propriedades.

Ao rodar localmente, conferir 320, 375, 768, 1024 e 1440 px; navegar com Tab/Enter/Espaço/Escape; testar filtros seguidos dos atalhos do laboratório; desativar JS e bloquear a imagem da cena; ativar movimento reduzido no sistema; ampliar/fechar as capturas; conferir e-mail e GitHub.

Nenhum deploy ou push foi realizado.

## Diagnóstico de abertura após a entrega

O endereço de loopback informado na entrega não correspondia a uma prévia acessível ao usuário. Não havia servidor ativo. Ao tentar a infraestrutura oficial, tanto `sites-preview status` quanto `sites-preview start /workspace` retornaram `preview relay unavailable: No such file or directory (os error 2)`. Não foi gerada URL externa e não houve publicação para contornar a restrição do titular.

O README agora distingue execução no próprio computador e ambiente remoto. Abrir localmente exige rodar o comando na máquina do navegador, ou abrir `index.html` com os demais arquivos do projeto preservados.

### Causa adicional encontrada e corrigida

Ao testar a inicialização real, `npm run dev` iniciou mas respondeu 404 para `/`. A variável `project` terminava com separador, e a checagem de segurança acrescentava outro: o prefixo exigido era `/workspace//`, diferente do caminho normalizado `/workspace/index.html`. Corrigido com `resolve(fileURLToPath(...))`, preservando a restrição de acesso aos arquivos públicos.

Após reiniciar o servidor, foram confirmadas respostas HTTP 200 para `/`, `/index.html`, CSS, JavaScript, os dois SVGs, três capturas PNG e três fontes TTF. HEAD da página inicial retornou 200 sem corpo. Foram acrescentados testes de regressão HTTP para os modos dev e dist, incluindo arquivos privados bloqueados e métodos não suportados. O log do servidor agora também informa a porta efetiva ao usar `PORT=0` nos testes.

`npm run check` e `npm test` passaram após a correção: 11 testes lógicos e 90 asserções HTTP. O comando de testes agora gera o build antes de verificar dist, funcionando também numa pasta sem build prévio. A validação de acesso a arquivos também passou a usar o caminho normalizado, bloqueando tentativas de sair de assets por caminhos codificados.

A correção resolve a resposta 404 do servidor. Ela não restaura o relay de preview ausente nesta sessão.

## Atualização de renderização desktop

Após solicitação explícita de visualização, o site foi aberto no Chromium headless instalado no ambiente. Foram capturadas a primeira tela e a página completa (1440 px de largura, aproximadamente 4382 px de altura), usando os arquivos efetivos servidos em HTTP. Título, estado de documento completo e carregamento visual das capturas dos projetos foram conferidos. As imagens de verificação estão em work/portfolio-desktop.png e work/portfolio-full.png. Essa inspeção confirma a renderização desktop, sem comprovar teclado, toque, leitor de tela ou acesso externo. O relay de preview e a exportação de arquivos continuam indisponíveis.
