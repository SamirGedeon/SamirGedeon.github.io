# Fluido WebGL — oitava versão

## Correção do efeito

A versão vetorial foi removida. O motor agora simula fluido na GPU, adaptando WebGL Fluid Simulation de Pavel Dobryakov, fonte oficial MIT identificada em docs/fluid-source.md. Não é um desenho de listras nem uma imagem de grade pequena ampliada.

A configuração foi conferida no bundle público atual de https://www.aaabadcode.com/: velocidade 128, pigmento nominal 1440, dissipação de densidade 0,5, velocidade 3, pressão 0,1, 20 iterações, curl 3, raio 0,2 e força 6000. Cores HSV aleatórias são multiplicadas por 0,15 e atualizadas dez vezes por segundo. O canvas usa composição normal com RGB e alfa pré-multiplicados, sem blur nem modos multiply/screen. A superfície clara do contato é branca, permitindo a apresentação pastel da referência.

O campo de cor é independente do campo de velocidade e limitado a 4 milhões de pixels, preservando a proporção. A simulação recebe gestos do mouse e deixa a cauda evoluir por vários segundos; os últimos dois segundos desvanecem, e após sete segundos o canvas é limpo e ocultado. O motor é iniciado sob demanda. Redução de movimento, dispositivos restritos, telas compactas, aba oculta, saída da seção, falhas e perda do contexto gráfico cancelam os frames e liberam recursos. Os textos, links, projetos e currículo não dependem do efeito.

## Testes

Passaram a verificação estática, 26 testes de interação, 8 testes de integração e ciclo de vida do fluido, 4 testes de entradas e 300 asserções HTTP. Os testes com stubs verificam dimensionamento, gestos, pigmento, máscaras, dissipação, perda/restauração do contexto e fallback sem GPU.

Além dos stubs, o JavaScript real do motor foi executado em Node com registro das chamadas WebGL. As chamadas foram reproduzidas em EGL surfaceless e OpenGL ES 3.2 Mesa/llvmpipe, compilando os shaders reais e executando as operações reais em texturas e framebuffers. Cada variante compilou 18 objetos de shader e ligou 9 programas sem erros. O caminho GLSL 300 realizou 2783 desenhos, usando pigmento de 2618×1440 no teste; o caminho GLSL 100 com interpolação manual realizou 1053 desenhos. Nesse segundo caminho, os formatos da extensão half-float de WebGL 1 são traduzidos para os equivalentes do contexto GLES 3 de teste.

As imagens renderizadas foram inspecionadas: mostram pigmentos suaves e redemoinhos. Os testes numéricos confirmaram que máscara e fade reduzem RGB e alfa juntos, e que clear remove todo o pigmento. Resultados e uma imagem estão em docs/gpu-v8; as imagens são do efeito isolado, não capturas da página. O comando opcional npm run test:gpu reproduz essa verificação em Linux com as bibliotecas do sistema necessárias.

## Limites

A referência foi inspecionada por HTML e código público, sem sessão interativa. A página completa não foi validada em navegador nesta rodada, porque a ferramenta de prévia/CUA está indisponível. A renderização OpenGL verifica o motor e os shaders; não confirma a composição da página em todos os navegadores, a integração específica do driver do visitante, nem igualdade pixel a pixel com a referência. O resultado de um fluido também depende do movimento do mouse e da dimensão da tela.
