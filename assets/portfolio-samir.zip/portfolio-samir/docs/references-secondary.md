# Análise de referências — três sites

Inspeção em 10/11/2026. As três URLs foram abertas com a ferramenta web. Aahana e Redoy retornam shells renderizados por JavaScript, sem texto legível nessa ferramenta; para eles foram lidos o HTML e os CSS/bundles públicos. Não houve navegador interativo disponível, portanto as observações abaixo descrevem estrutura/estilos/handlers confirmados no material entregue, e não uma avaliação visual de screenshot nem um teste de funcionamento de ponta a ponta. Nenhum código ou asset destas referências deve ser incorporado ao portfólio.

## Aahana Bobade — https://www.aahanabobade.com/

Evidências locais: `aahana.html`, `aahana.txt`, `aahana-style.txt` neste diretório. Assets públicos inspecionados: `/assets/index-rCYUBzIM.js` e `/assets/index-C4rzL3lx.css`.

- A estrutura usa a metáfora explícita de um editor VS Code: barra de título/menu, trilho de atividade, Explorer lateral, editor com abas de arquivos e barra de status. As seções têm nomes de arquivos e comentários de código (home, about, projects, skills, experience, contact, readme).
- O CSS confirma base cinza escuro (#1e1e1e) e cores de sintaxe azul/ciano, verde, laranja, roxo. Corpo em JetBrains Mono e títulos Syne.
- Existem temas alternativos (Rose Pine, Tokyo Night, Catppuccin, Nord, Gruvbox etc.), navegação por abas, terminal com comandos `ls`, `pwd`, `clear` e abertura de arquivo, além de paleta de comandos Ctrl+P; Ctrl+B alterna lateral, Ctrl+` alterna terminal e Esc fecha overlay.
- A composição compacta abaixo de 1024 px altera o grid de editor para uma coluna com botão de Explorer.
- O que aproveitar como princípio: o ambiente expressa trabalho com software; controles dão acesso real a conteúdo, e há atalhos além do mouse. Para Samir, adotar objetos de laboratório com função e rótulos, sem clonar um editor nem exigir que o visitante saiba comandos.

## Redoyanul Haque — https://www.redoyanulhaque.me/

Evidências locais: `redoy.html`, `redoy.txt`, `redoy-style.txt`, `redoy-MainContainer-CNANTDSP.js`, `redoy-MainContainer-HGT2vxzP.css`, `redoy-Navbar-CBrEUVVF.js`, `redoy-index-BIjuiFGS.js`.

- O CSS confirma fundo quase preto (#0b080c), texto claro (#eae5ec), acento lavanda (#c2a4ff), tipografia Geist e títulos grandes, incluindo gradiente branco/violeta em título de trajetória.
- Navegação explícita para About, Work e Contact acompanha a experiência; projetos são representados por imagens reais e alguns têm vídeo exibido no hover. Há uma página separada `/myworks` com coleção numerada de trabalhos.
- O código monta um personagem 3D com renderer WebGL, iluminação de ambiente e ponto, introAnimation e rotação interpolada em resposta ao mouse. O scroll transforma câmera, personagem e blocos de texto, conectando a cena à progressão de conteúdo.
- O código mantém comportamento móvel próprio: elimina a tela de loading em largura <=768 px, flexibiliza scroll no CSS e pula parte das timelines desktop. A carga do modelo 3D ainda existe; não foi verificada sua leveza.
- O que aproveitar como princípio: um único objeto central pode criar identidade e conectar seções. Para Samir, tornar o foco uma bancada de desenvolvimento, com interação curta, sem preloader bloqueante nem câmera que seja necessária para acessar conteúdo.

## Aaabadcode — https://www.aaabadcode.com/

Evidências locais: `aaabadcode.html`, `aaabadcode-page.txt`; HTML também legível na ferramenta web. Atenção: a URL atualmente entrega título/metadata “Toukoum Portfolio”, apresentação “Aaaaby” e links de autoria Toukoum. Não atribuir uma identidade distinta sem essa ressalva.

- HTML confirma hero centralizado e claro, apresentação curta, função em h1 grande, imagem Memoji central, campo de pergunta e cinco botões de assunto (Me, Projects, Skills, Fun, Contact).
- Estilos confirmam botões translúcidos com borda arredondada, ícones com cores distintas, feedback de escala ao ativar e hierarquia tipográfica responsiva.
- Handler dos botões e envio do campo leva a `/chat?query=...` com perguntas predefinidas. Existe um modal de apresentação com CTA e fechamento.
- Um canvas fixo de fluido fica atrás do conteúdo; o bundle inclui simulação WebGL e eventos de ponteiro. Não foi testado visualmente.
- O que aproveitar como princípio: reduzir a escolha inicial a poucos destinos de conteúdo com verbos e símbolos claros. Para Samir, três estações (interfaces, APIs, trajetória) podem explicar o laboratório sem chatbot, promessa de IA ou efeito fluido copiado.

## Direção original compatível

“Bancada de software”: tipografia expressiva + bancada em perspectiva com módulos de interface e API, cada um contendo um botão HTML real que revela um texto curto e leva à seção correspondente. A metáfora une código (Aahana), objeto espacial narrativo (Redoy) e atalhos orientados a assunto (Aaabadcode). Manter navegação convencional, CTA de projetos sempre visível e versão sem movimento como comportamento de primeira classe. Cores, ilustração, objetos, textos e disposição devem ser próprios.
