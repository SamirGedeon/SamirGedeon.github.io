# Revisão visual e funcional — terceira versão

## O que mudou

A foto atual foi enviada por Samir na conversa. O fundo foi removido com a ferramenta de edição de imagem e uma camada artística foi criada a partir do mesmo recorte. Os dois assets possuem canvas de 1262 × 1246 pixels com alpha e composição alinhada. O original das gerações permanece no ambiente de trabalho; a distribuição usa WebP com transparência, cerca de 279 KB e 408 KB.

O retrato usa fundo branco, sem moldura de fotografia ou fade nos ombros. O lado visual recebe o tratamento de pintura e o lado de código usa o recorte fotográfico. O divisor tem precisão de 0,1% no ponteiro, setas do teclado de 1% e indicação acessível arredondada. As descrições laterais ficam visualmente ocultas no celular para não atravessar o cabelo e os rótulos.

O editor foi ampliado e passou a usar tons neutros de IDE, barra de atividades com SVGs, explorador que abre arquivos, abas superiores, breadcrumb, currículo para download, badges de tecnologias em estudo e gutter de linhas. O conteúdo continua factual. Abas e explorador sincronizam seleção, foco e linguagem na barra de status.

Sombras duras de extrusão e halos pesados foram removidos dos cartões. A sombra do editor é discreta. Textos menores foram aumentados, e o contato agora usa branco e textos escuros para preservar contraste durante o efeito colorido.

O efeito de contato agora é uma simulação original de tinta em grade limitada: advecção, pressão e vorticidade, com cyan, lilás, rosa e lima. A simulação é acionada apenas pelo movimento do mouse, limpa e para após 1150 ms sem nova entrada e fica desativada em celular, dispositivos restritos, aba oculta e movimento reduzido. Nenhum código ou asset das referências foi copiado.

## Validação

- Revisão visual desktop da página completa e da primeira tela, incluindo alinhamento das duas camadas do retrato e ausência do fundo do quarto.
- Navegador: arraste nativo por mouse e toque, setas, seleção de abas, explorador, JSON de estudos válido, foco, filtros, link de tecnologia para projeto filtrado, modal e Escape, download real do currículo e comparação dos bytes.
- Cena de tecnologias muda de matriz durante rolagem real; movimento reduzido do sistema e manual cancelam movimento e canvas.
- Rastro de tinta pinta pixels e zera após a curta duração. Sem laço de animação em repouso.
- Sem transbordamento horizontal em 320, 375, 414, 768, 1024 e 1440 px. Abas superiores têm orientação horizontal em todas as larguras.
- Conteúdo, projetos, currículo e contatos continuam disponíveis sem JavaScript.
- Verificações estáticas cobrem assets, âncoras, IDs, ARIA e sintaxe. Testes HTTP cobrem os novos WebP e todos os tipos já usados, inclusive PDF e ZIP.
- Arquivos CSS/JS e ZIP receberam versão na URL para evitar que a revisão carregue assets antigos do cache.

## Limites

Não foi executada auditoria completa com leitor de tela nem teste físico em vários celulares. O toque foi emulado pelo navegador. As imagens são tratamentos derivados da foto enviada, e não fotografias novas.
