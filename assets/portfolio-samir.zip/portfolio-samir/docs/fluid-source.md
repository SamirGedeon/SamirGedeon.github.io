# Fonte e integração do fluido WebGL

O motor em `assets/fluid-engine.js` adapta os shaders e o algoritmo de **WebGL Fluid Simulation**, de Pavel Dobryakov, com licença MIT. A origem é o repositório oficial [PavelDoGreat/WebGL-Fluid-Simulation](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation), commit [`a2d292931f19d9b3b9f564e23e6c32729d2121c3`](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation/tree/a2d292931f19d9b3b9f564e23e6c32729d2121c3). A licença e o copyright de 2017 foram preservados em `assets/vendor/fluid-LICENSE.txt` e no cabeçalho do motor.

A implementação usa campos separados de velocidade, pressão e pigmento em texturas half-float. Cada passo calcula curl, confinamento de vorticidade, divergência, 20 iterações de pressão, subtração do gradiente e advecção dos campos. O desenho final usa cor e alfa pré-multiplicados, com sombreado da densidade. Isso produz mistura e redemoinhos, sem as faixas vetoriais da versão anterior.

Não foram incorporados identidade, imagens, textos ou o bundle minificado do site de referência. O código adaptado vem da fonte MIT indicada acima. O motor não tem dependências de produção, painel de controle, áudio, sementes aleatórias de pigmento, listeners globais ou loop próprio de animação.

## Configuração

Os valores padrão mantêm resolução de velocidade 128, resolução nominal de pigmento 1440, dissipação de densidade 0,5, dissipação de velocidade 3, pressão inicial multiplicada por 0,1, 20 iterações de pressão, curl 3, raio de splat 0,2 e força de splat 6000.

A resolução nominal é o eixo curto do campo, preservando a proporção da seção. O pigmento é limitado a 4 milhões de pixels e ao `MAX_TEXTURE_SIZE` da GPU; a redução preserva a proporção. O canvas usa DPR até 2 e o mesmo orçamento de 4 milhões de pixels. A resolução de velocidade permanece independente da resolução de cor.

WebGL2 usa formatos RGBA16F, RG16F e R16F quando renderizáveis. WebGL1 usa `OES_texture_half_float` com RGBA e verifica o framebuffer. Na ausência de filtro linear adequado, o shader de advecção faz interpolação bilinear manual. Sem half-float renderizável ou se a compilação falhar, a fábrica retorna `null`; o conteúdo do portfólio permanece independente do efeito.

## Contrato com a página

`window.SamirFluid.create(canvas, options)` retorna um motor ou `null`. As opções podem substituir os valores de `SamirFluid.defaults`; `onFailure(error)` recebe uma falha de inicialização.

- `setSize(cssWidth, cssHeight, dpr)` aloca ou redimensiona os campos. Dimensões são pixels CSS.
- `splat({ x, y, dx, dy, color })` injeta velocidade e pigmento. Coordenadas e deslocamentos usam pixels CSS, com origem no canto superior esquerdo. O motor converte para UV, corrige a proporção e aplica a força 6000. `color` é um array RGB já escalado, normalmente HSV aleatório multiplicado por 0,15. Sem cor fornecida, usa esse mesmo padrão.
- `step(dtSeconds)` avança a simulação, limitando cada passo a 1/60 de segundo.
- `render({ opacity, mask })` limpa o framebuffer da tela com RGBA zero e apresenta o pigmento. `mask` contém até 12 retângulos `{ x, y, width, height }` em pixels CSS. A proteção possui borda suave e reduz cor e alfa igualmente, preservando a composição pré-multiplicada.
- `clear()` zera campos e canvas; `destroy()` libera texturas, framebuffers, programas e buffer de vértices.
- `quality` informa uma cópia das dimensões efetivas e dos modos de filtragem/contexto.

A página controla gestos, preferência de movimento reduzido, dispositivos restritos, visibilidade, temporização, desvanecimento e interrupção da animação. O motor não agenda frames por conta própria.
