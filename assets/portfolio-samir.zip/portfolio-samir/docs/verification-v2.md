# Validação da segunda versão

Implementação solicitada: foto interativa, editor com abas e currículo, tecnologias com profundidade e movimento na rolagem, efeito de ponteiro em área clara, tipografia e fundo minimalistas.

## Verificado

- Retrato: foto real do perfil público GitHub, divisor movido por mouse, toque nativo em viewport móvel e setas do teclado; presets funcionais e valor acessível.
- Editor: seleção por clique e teclado, movimentação de foco e seleção por setas e End; um painel visível por vez com JavaScript. Conteúdo de todos os painéis permanece no HTML.
- Currículo: PDF de uma página A4 com texto extraído por pdftotext, seis links reais; clique no site gera download, e o arquivo baixado é idêntico ao PDF de origem.
- Tecnologias: oito seleções funcionam; descrição e link seguem o item selecionado. O link revela um projeto oculto pelo filtro. Matriz 3D muda com rolagem real.
- Contato: o gesto do ponteiro desenha pixels no canvas; eles desaparecem após o tempo previsto. O canvas é ocultado no celular e no modo reduzido.
- Preferências: modo reduzido do sistema prevalece, desliga o efeito e torna a cena estática; controle manual persistente funciona.
- Layout: renderização no Chromium sem transbordamento horizontal em 320, 375, 414, 768, 1024 e 1440 px.
- Modal de capturas: abre e coloca foco no fechamento; Escape nativo fecha e devolve o foco ao acionador.
- Sem JavaScript: quatro projetos, três conteúdos do editor, contatos e download do CV continuam disponíveis; controles incompletos ficam ocultos.
- Arquivos: retrato, fontes e capturas locais carregados; links de contato confirmados. Nenhuma exceção JavaScript não tratada durante a bateria.
- Testes de lógica: 15 cenários no DOM emulado. Testes HTTP verificam arquivo real, MIME, tamanho, HEAD, métodos e negação de caminhos privados e traversal codificado nos modos dev e dist.

## Limites

Não foi feita auditoria manual com leitor de tela nem teste físico em todos os modelos de celular. Os gestos móveis foram executados pelo navegador com emulação de toque. A cena tem profundidade em CSS; o efeito de pigmento é um rastro 2D breve, sem simulação de fluidos WebGL ou dependências adicionais.

## Fontes

Foto: avatar público de SamirGedeon, obtido da API pública GitHub. PDF: dados fornecidos por Samir e evidências de docs/projects.json. Fontes: Archivo (Google Fonts/OFL) e DM Sans para símbolos (OFL). Nenhum asset dos sites de referência foi copiado.
