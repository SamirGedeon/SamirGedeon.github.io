# Direção autoral e análise das referências

Consulta em 10/11/2026, antes da programação do site. As seis URLs abriram na ferramenta web; Aahana e Redoy fornecem shells JS, complementados pela leitura de HTML, CSS e bundles públicos. Foram vistas as imagens públicas de apresentação de Adham, Bruno e Majd. Essas imagens são evidências de direção, não screenshots de uma sessão de navegação. Não foi possível experimentar os sites num navegador interativo, porque a sessão não ofereceu a ferramenta de controle do desktop.

## O que funciona em cada referência

| Referência | Elementos confirmados | Princípio aproveitado |
| --- | --- | --- |
| [Adham Dannaway](https://www.adhamdannaway.com/) | Apresentação designer/coder, retrato dividido entre arte e código, navegação direta, trabalhos logo após a apresentação. CSS prevê composição deslizante do rosto e adaptação responsiva. | Explicar a pessoa rapidamente e deixar os projetos próximos da entrada. Não foi copiado o retrato dividido. |
| [Bruno Simon](https://bruno-simon.com/) | Universo espacial ilustrado, exploração por veículo, objetos e descobertas, controles para mouse/teclado/toque/gamepad, opções de qualidade, áudio e recuperação. A imagem pública mostra mundo tridimensional estilizado; página confirma Three.js. | Usar espaço e objetos como caminhos de conteúdo. Não foram usados carro, mapa, mundo ou mecânica de dirigir. |
| [Aahana Bobade](https://www.aahanabobade.com/) | Editor com Explorer, abas, terminal, temas e atalhos; cores de sintaxe e JetBrains Mono/Syne. | A própria experiência pode falar de software. Objetos com rótulos substituem comandos e janelas de editor. |
| [Redoyanul Haque](https://www.redoyanulhaque.me/) | CSS escuro/lavanda e títulos Geist; personagem WebGL responde ao ponteiro e câmera acompanha scroll; projetos com imagem/vídeo e navegação convencional. | Um objeto espacial central cria identidade. Aqui a cena é contida e não controla a rolagem. |
| [Aaabadcode](https://www.aaabadcode.com/) | A URL atualmente apresenta identidade Toukoum/Aaaaby: hero claro, Memoji, pergunta e cinco atalhos de assunto; canvas de fluido e feedback de botão no código. | Oferecer poucas escolhas claras para começar a explorar. Sem chatbot, avatar ou simulação de fluido. |
| [Majd](https://majd-portfolio.framer.website/) | Imagem de apresentação com tipografia preta enorme, fundo claro, retrato e detalhes espaciais; HTML/CSS confirma Archivo, projetos destacados e fluxo até contato. | Tipografia como elemento de composição, hierarquia forte e alternância de ritmo. Sem reproduzir o hero ou os módulos do template. |

Detalhes técnicos das três referências pesquisadas em paralelo estão em `references-secondary.md`.

## Conceito: ideias em construção

Um laboratório de software compacto. Monitor representa interfaces, servidor representa APIs e dados, caderno representa formação e estudos. A cena e os objetos foram desenhados especificamente para este portfólio.

Fundo carvão, letras creme, verde elétrico e lilás conectam o laboratório a código e experimentação. O título é expressivo, e os pequenos rótulos monoespaçados funcionam como anotações de bancada. A seção de projetos clareia a composição e dá prioridade às prévias reais; a trajetória volta ao escuro e o contato termina em verde.

Foi escolhida uma ilustração isométrica com profundidade em SVG/CSS em vez de acrescentar Three.js ao workspace vazio: o efeito espacial e a interação de exploração cabem em um arquivo de cerca de 10 KB. Essa escolha elimina a necessidade de contexto WebGL e mantém a versão móvel simples. Não há navegação espacial obrigatória, espera de carregamento nem câmera ligada ao scroll.

Os controles têm finalidade: escolher uma estação revela informação e um link real; filtros ajudam a separar interfaces de APIs; ampliação permite ler os projetos. O movimento é curto, opcional e acompanha apenas o ponteiro do mouse. As rotas convencionais e todo conteúdo permanecem no HTML.
