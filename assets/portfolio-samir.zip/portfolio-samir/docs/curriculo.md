# Samir Gedeon Machado

Desenvolvimento web e APIs

- Miguel Pereira, RJ
- E-mail: samirgd173@gmail.com
- GitHub: https://github.com/SamirGedeon

## Objetivo

Busco oportunidades de desenvolvimento júnior e projetos freelance. Desenvolvo projetos web e APIs enquanto aprofundo meus estudos em Engenharia de Software.

## Formação

Engenharia de Software na Universidade de Vassouras. Conclusão prevista em 2027.

## Experiência

Estágio na área de TI da Prefeitura de Miguel Pereira.

## Tecnologias em estudo

Java, Spring Boot, Python, Django REST, SQL/MySQL, HTML, CSS e JavaScript.

## Projetos selecionados

- **[Controle de estoque](https://github.com/SamirGedeon/estoque-spring-api)** — Painel de produtos com busca por nome, edição e persistência. Java 17, Spring Boot, JDBC e H2.
- **[Drew Studio](https://github.com/SamirGedeon/Lading-Page)** — Site de estúdio fictício com tema claro/escuro e briefing para download. HTML, CSS e JavaScript.
- **[Fruta — Vitrine de sabores](https://github.com/SamirGedeon/Site-Refri)** — Vitrine fictícia com três sabores, carrossel circular e navegação pelo teclado. HTML, CSS e JavaScript.
- **[Catálogo de jogos](https://github.com/SamirGedeon/catalogo-jogos-api)** — Listagem JSON, filtro de jogos em andamento e Django Admin. Python, Django e SQLite.

## Idiomas

Inglês básico.

---

Conteúdo baseado nas informações fornecidas por Samir e nas evidências de `projects.json`. Não foram acrescentados períodos de estágio, atribuições, resultados, clientes ou níveis de domínio de tecnologias.
