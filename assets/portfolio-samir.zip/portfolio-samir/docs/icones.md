# Ícones dos arquivos

O editor usa os SVGs oficiais do [Material Icon Theme](https://github.com/material-extensions/vscode-material-icon-theme), conjunto reconhecido de ícones de arquivos para o VS Code, no commit `ced21b9b5241c1efa502a8c46ec7363a690a7058`. Os arquivos ficam em `assets/icons`, são servidos pelo próprio portfólio e não requerem pacote, fonte ou CDN.

| Arquivo apresentado | Tipo confirmado | SVG oficial |
| --- | --- | --- |
| `sobre.md` | Markdown | `markdown.svg` |
| `estudos.json` | JSON | `json.svg` |
| `projetos.js` | JavaScript | `javascript.svg` |
| `curriculo.pdf` | PDF, link para o currículo real | `pdf.svg` |

Os mesmos SVGs aparecem nas abas, no explorador, no menu de arquivos e nos atalhos de reabertura. Todos têm dimensões consistentes e são decorativos (`alt=""`, `aria-hidden="true"`); os nomes dos arquivos permanecem como texto visível e acessível. Os desenhos e as cores oficiais foram preservados, sem filtros ou recoloração: azul Markdown, dourado JSON, amarelo JavaScript e vermelho PDF.

Fonte exata: https://github.com/material-extensions/vscode-material-icon-theme/tree/ced21b9b5241c1efa502a8c46ec7363a690a7058/icons

Licença MIT e copyright preservados em `assets/icons/LICENSE-material-icon-theme.txt`.


## Bancada de tecnologias

Java, Python, Django, banco de dados, HTML e CSS também usam os SVGs oficiais do mesmo commit do Material Icon Theme; JavaScript reutiliza `javascript.svg`. O desenho de banco de dados representa a categoria SQL/MySQL e não atribui um banco não confirmado aos projetos.

Spring usa o SVG oficial de [Devicon](https://github.com/devicons/devicon/blob/master/icons/spring/spring-original.svg), sem recoloração. O arquivo `assets/icons/spring.svg` e a licença MIT correspondente em `assets/icons/LICENSE-devicon.txt` são locais. As cores oficiais foram preservadas. Todos os ícones são decorativos; nomes e descrições permanecem como texto HTML.
