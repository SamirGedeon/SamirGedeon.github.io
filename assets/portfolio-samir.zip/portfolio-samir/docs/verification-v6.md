# Retrato, rastro e ícones — sexta versão

O rastro do contato nasce de uma fonte estreita, com campo de velocidade mais amplo para abrir a cauda. A entrada é interpolada pela distância real entre os eventos; a grade é limitada a 19.360 células e não há animação em repouso. Mantém a paleta saturada, máscara de leitura, parada após 1150 ms e desativação por movimento reduzido, tela compacta, dispositivo restrito ou aba oculta.

No retrato, o extremo design oculta todo o bloco de código e seus fragmentos decorativos, substituindo-o por uma curva Bézier com controles e amostras de cor. No extremo código, o bloco design desaparece e surgem conexões e um fragmento de JavaScript decorativo. O centro restaura ambas as apresentações. As notas entram após o conteúdo oposto sair, evitando sobreposição. São SVGs originais marcados como decorativos, sem afirmações novas de experiência ou de projetos. Sem JavaScript, os dois blocos originais continuam disponíveis.

O editor usa os SVGs oficiais do Material Icon Theme, armazenados localmente e correspondentes às extensões reais. Origem e licença em docs/icones.md e assets/icons/LICENSE-material-icon-theme.txt. Fechamento e reabertura de abas foram preservados.

Passaram a verificação estática, 25 testes de interação em DOM emulado, 7 testes do fluido com stubs Canvas2D, 4 testes das entradas com stubs IntersectionObserver e 210 asserções HTTP. Os testes do fluido conferem largura do núcleo, continuidade, cores, máscara e cancelamento. O novo teste de retrato confere os três estados e o funcionamento manual com movimento reduzido e dispositivos limitados.

Não foi executada validação visual em navegador nesta rodada: a ferramenta de prévia/CUA não está disponível no ambiente. Os testes com stubs e HTTP não confirmam composição, aparência, layout responsivo nem gestos nativos. As capturas antigas pertencem às versões anteriores.
