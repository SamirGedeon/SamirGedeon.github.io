# Temas e interação do retrato — quarta versão

## Mudanças implementadas

### Temas

O tema claro usa creme quente, texto preto e uma textura estática de papel desenhada para o projeto em `assets/paper-grain.svg`. A textura é discreta, não intercepta o ponteiro e não possui animação.

O tema escuro usa fundo quase preto, textos claros e acentos de lavanda e azul. Cabeçalho, retrato, botões, filtros, metadados de projetos, bancada de tecnologias, contato, rodapé e diálogo receberam cores próprias. O editor mantém sua superfície neutra de IDE, com detalhes de status adaptados à paleta escura. Fotografias e capturas dos projetos não são invertidas.

A inicialização consulta a escolha válida em `localStorage` (`samir-theme`) e, na ausência dela, a preferência `prefers-color-scheme` do sistema. Um script curto no cabeçalho aplica o tema inicial antes da folha de estilos. A escolha pelo botão é persistida quando o armazenamento está disponível. Quando não há preferência explícita, mudanças do sistema atualizam o tema; uma escolha salva prevalece. Falhas de armazenamento não bloqueiam a troca durante a visita.

O botão do cabeçalho é uma ação nativa. Seu texto, título e nome acessível informam o modo de destino: ativar modo claro ou ativar modo escuro. O atributo `theme-color` também acompanha a escolha. Com JavaScript desativado, a base clara continua legível e o controle dependente de script permanece oculto.

### Retrato

As duas camadas transparentes usam a mesma composição e ficam alinhadas: retrato natural e tratamento artístico derivado da foto enviada por Samir. Em dispositivo com mouse e movimento permitido, mover o ponteiro para a esquerda revela design; mover para a direita revela código. Não é necessário manter o botão do mouse pressionado.

O acompanhamento usa interpolação curta e encerra os frames ao atingir o destino. Uma pequena zona central preserva o equilíbrio entre as duas camadas. Ao sair da área, a composição retorna ao centro quando o controle não está focado. O foco no controle manual preserva a seleção do visitante.

Arraste, toque, botões de seleção e setas do teclado continuam funcionando. O valor acessível descreve o lado revelado ou a divisão entre os dois lados. O acompanhamento automático não é aplicado no celular, em dispositivos restritos, em aba oculta ou quando o movimento reduzido está ativo.

### Rolagem e movimento reduzido

A página mantém a rolagem nativa. Entradas suaves e deslocamentos pequenos são aplicados somente ao conteúdo que ainda está fora do campo de visão. A animação não é requisito para acessar projetos ou informações.

A configuração de movimento reduzido do sistema prevalece sobre a preferência salva do site. Ela interrompe o acompanhamento automático do retrato, as entradas de rolagem, o movimento da bancada de tecnologias e o canvas de tinta. O botão do site permite reduzir o movimento quando o sistema não o exige. Conteúdo e controles manuais continuam disponíveis.

## Revisão de contraste por leitura de estilos

Foram conferidos os overrides escuros de textos que anteriormente usavam cores fixas: títulos do retrato, descrições, rótulos dos projetos, filtros, cartões, contato, rodapé e diálogo. Os pares representativos de texto principal, texto secundário, botão e legenda de cartão selecionado atingem o contraste mínimo de texto comum. Os elementos decorativos com baixa opacidade são separados do conteúdo principal e marcados como ocultos para tecnologia assistiva quando aplicável.

## Conferência visual

Foram conferidas capturas da versão clara e da versão escura no desktop, além da versão escura em viewport móvel. A revisão visual cobriu as cores, a composição do retrato e a adaptação do layout. As capturas também registram os estados do retrato durante a exploração com o mouse.

## Pontos da bateria final de navegador

- Inicialização com preferências clara e escura do sistema, escolha explícita salva e armazenamento indisponível.
- Troca pelo botão, persistência após recarregar, nome acessível e cor da interface do navegador.
- Retrato acompanhando o mouse sem clique, arraste manual, teclado, toque e retorno ao estado central.
- Camadas alinhadas nos extremos e no meio, sem corte do cabelo e sem fundo da foto original.
- Legibilidade de projetos, editor, tecnologias, contato e diálogo nos dois temas.
- Layout do cabeçalho e ausência de transbordamento em telas estreitas, incluindo os controles de tema e currículo.
- Movimento reduzido do sistema e do site, conteúdo sem JavaScript e encerramento dos frames em repouso.
- Downloads do currículo e do projeto, além dos filtros, links e foco do diálogo preservados.

## Limites

Esta nota descreve as mudanças e a revisão de estilos, sem atribuir contagens a testes. A bateria final registra os resultados funcionais e visuais da versão publicada. Não substitui auditoria completa com leitor de tela nem testes físicos em vários aparelhos; eventos móveis podem ser verificados por emulação no navegador.
