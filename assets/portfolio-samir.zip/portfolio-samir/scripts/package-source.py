"""Build the downloadable source ZIP from an explicit, credential-free file list."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import re

root = Path(__file__).resolve().parent.parent
archive = root / 'assets' / 'portfolio-samir.zip'
temporary = archive.with_suffix('.zip.tmp')
entries = ['index.html', 'styles.css', 'app.js', 'package.json', '.gitignore',
           'README.md', 'SECURITY.md', 'assets', 'scripts', 'worker', 'tests', 'docs']
private_name = re.compile(r'^(?:\.env(?:\.|$)|credentials?(?:[.-]|$)|secrets?(?:[.-]|$)|id_(?:rsa|ed25519))|\.(?:pem|key|p12|pfx|sqlite3?|db)$', re.I)
files = []
for entry in entries:
    path = root / entry
    for file in sorted(path.rglob('*')) if path.is_dir() else [path]:
        if file in {archive, temporary}:
            continue
        if file.is_symlink():
            raise SystemExit(f'Link simbólico recusado no pacote: {file.relative_to(root)}')
        if not file.is_file():
            continue
        relative = file.relative_to(root)
        if '__pycache__' in relative.parts or file.suffix == '.pyc':
            continue
        if any(private_name.search(part) or part in {'.git', '.openai', 'work', 'node_modules', '__pycache__'} for part in relative.parts):
            raise SystemExit(f'Arquivo privado recusado no pacote: {relative}')
        files.append(file)
# No output is replaced until the complete input list has passed validation.
try:
    with ZipFile(temporary, 'w', ZIP_DEFLATED, compresslevel=9) as output:
        for file in files:
            output.write(file, Path('portfolio-samir') / file.relative_to(root))
    with ZipFile(temporary) as output:
        assert output.testzip() is None
        for file in files:
            assert output.read(str(Path('portfolio-samir') / file.relative_to(root))) == file.read_bytes()
    temporary.replace(archive)
finally:
    temporary.unlink(missing_ok=True)
print(f'ZIP íntegro: {len(files)} arquivos, {archive.stat().st_size} bytes.')
