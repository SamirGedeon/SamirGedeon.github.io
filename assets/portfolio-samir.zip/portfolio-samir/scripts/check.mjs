import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const project = fileURLToPath(new URL('../', import.meta.url));
const html = await readFile(resolve(project, 'index.html'), 'utf8');
const css = await readFile(resolve(project, 'styles.css'), 'utf8');
const errors = [];
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
if (new Set(ids).size !== ids.length) errors.push('Há IDs duplicados.');
const links = [...html.matchAll(/\b(?:href|src)="([^"]*)"/g)].map(match => match[1]);
const cssAssets = [...css.matchAll(/url\(['"]?([^'")]+)['"]?\)/g)].map(match => match[1]);
for (const link of [...links, ...cssAssets]) {
  if (!link || /^(https?:|mailto:|data:)/.test(link)) continue;
  if (link.startsWith('#')) {
    if (!ids.includes(link.slice(1))) errors.push(`Âncora sem destino: ${link}`);
  } else {
    try { if (!(await stat(resolve(project, link.split(/[?#]/)[0]))).isFile()) errors.push(`Asset inválido: ${link}`); }
    catch { errors.push(`Asset ausente: ${link}`); }
  }
}
for (const match of html.matchAll(/aria-(?:controls|labelledby)="([^"]+)"/g)) {
  for (const id of match[1].split(' ')) if (!ids.includes(id)) errors.push(`Referência ARIA sem destino: ${id}`);
}
for (const match of html.matchAll(/<img\b[^>]*>/g)) if (!/\balt="[^"]*"/.test(match[0])) errors.push('Imagem sem atributo alt.');
for (const match of html.matchAll(/<a\b[^>]*target="_blank"[^>]*>/g)) if (!/rel="[^"]*noopener/.test(match[0])) errors.push('Link externo sem noopener.');
const research = JSON.parse(await readFile(resolve(project, 'docs/projects.json'), 'utf8'));
if (research.selected.length < 4 || research.selected.length > 6) errors.push('Quantidade de projetos fora do briefing.');
for (const item of research.selected) if (!html.includes(item.repository)) errors.push(`Repositório sem link: ${item.name}`);
for (const file of ['app.js', 'assets/fluid-engine.js', 'assets/i18n.js', 'assets/theme-init.js', 'scripts/build.mjs', 'scripts/build-worker.mjs', 'scripts/build-pages.mjs', 'worker/index.js', 'scripts/serve.mjs', 'scripts/check.mjs', 'tests/interactions.mjs', 'tests/server.mjs', 'tests/browser.mjs', 'tests/fluid.mjs', 'tests/motion.mjs', 'tests/gpu/record.mjs', 'tests/i18n.mjs', 'tests/dom-fixture.mjs', 'scripts/security.mjs', 'tests/security.mjs', 'tests/worker.mjs', 'tests/pages.mjs']) {
  try { execFileSync(process.execPath, ['--check', resolve(project, file)], { stdio: 'pipe' }); }
  catch (error) { errors.push(`Sintaxe inválida em ${file}: ${error.stderr}`); }
}
if (errors.length) {
  console.error(errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log(`Verificação concluída: sintaxe JS, ${ids.length} IDs, âncoras, assets, ARIA, imagens e ${research.selected.length} repositórios.`);
  console.log('Esta verificação estática não substitui testes visuais e interativos em navegador.');
}
