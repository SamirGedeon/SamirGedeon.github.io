import { mkdir, rm, cp, stat, readdir, writeFile } from 'node:fs/promises';
import { securityHeaders } from './security.mjs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const project = fileURLToPath(new URL('../', import.meta.url));
const destination = resolve(project, 'dist');
// Fail closed if a private file is accidentally placed in the public assets tree.
async function validateAssets(directory) {
  for (const entry of await readdir(directory, {withFileTypes:true})) {
    if (entry.isSymbolicLink() || entry.name.startsWith('.') || /\.(?:pem|key|p12|pfx|sqlite3?|db)$/i.test(entry.name) || /^(?:credentials|secrets?)(?:[.-]|$)/i.test(entry.name)) throw new Error('Arquivo privado ou link simbólico em assets: ' + entry.name);
    if (entry.isDirectory()) await validateAssets(resolve(directory,entry.name));
  }
}
await validateAssets(resolve(project,'assets'));
await rm(destination, { recursive: true, force: true });
await mkdir(destination, { recursive: true });
for (const file of ['index.html', 'styles.css', 'app.js', 'assets']) {
  await cp(resolve(project, file), resolve(destination, file), { recursive: true });
}
console.log(`Build estático gerado em ${destination}`);
console.log(`HTML: ${(await stat(resolve(destination, 'index.html'))).size} bytes. Sem instalação de dependências.`);

await writeFile(resolve(destination,'_headers'), '/*\n' + Object.entries(securityHeaders).map(([name,value]) => `  ${name}: ${value}`).join('\n') + '\n');
// Sites runs this read-only handler so its responses carry the policies too.
await import('./build-worker.mjs');
