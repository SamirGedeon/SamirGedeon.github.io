/** Compile the existing static frontend into a dependency-free Worker ESM. */
import {readFile,readdir,writeFile,mkdir} from 'node:fs/promises';
import {resolve,extname} from 'node:path';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';
import {securityHeaders} from './security.mjs';
const root=resolve(fileURLToPath(new URL('../',import.meta.url))),dist=resolve(root,'dist');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.ttf':'font/ttf','.txt':'text/plain; charset=utf-8','.pdf':'application/pdf','.zip':'application/zip','.woff2':'font/woff2'};
const assets={};
async function add(relative){const path=resolve(dist,relative),data=await readFile(path);assets['/'+relative]={data:data.toString('base64'),size:data.length,type:mime[extname(path)]||'application/octet-stream',etag:'"'+createHash('sha256').update(data).digest('hex')+'"'};}
async function walk(relative){for(const entry of await readdir(resolve(dist,relative),{withFileTypes:true})){if(entry.isSymbolicLink()||entry.name.startsWith('.'))throw Error('Non-public asset');const path=relative+'/'+entry.name;if(entry.isDirectory())await walk(path);else await add(path);}}
for(const file of ['index.html','styles.css','app.js'])await add(file);await walk('assets');
const template=await readFile(resolve(root,'worker/index.js'),'utf8');await mkdir(resolve(dist,'server'),{recursive:true});
const output=template+'\nexport default createPortfolioWorker('+JSON.stringify(assets)+','+JSON.stringify(securityHeaders)+');\n';
await writeFile(resolve(dist,'server/index.js'),output);
console.log('Worker ESM generated: '+Object.keys(assets).length+' explicit public routes; '+Buffer.byteLength(output)+' bytes.');
