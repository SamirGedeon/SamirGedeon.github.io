/** Build only the files that GitHub Pages may expose publicly. No dependencies. */
import { cp, lstat, mkdir, readdir, rm, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const project = fileURLToPath(new URL('../', import.meta.url));
const publicEntries = ['index.html', 'styles.css', 'app.js', 'assets'];
const privateName = /^(?:credentials?|secrets?)(?:[.-]|$)|^id_(?:rsa|ed25519)(?:[.-]|$)|\.(?:pem|key|p12|pfx|sqlite3?|db)$/i;

async function validateAssets(directory) {
  const info = await lstat(directory);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('A pasta assets deve ser um diretório público local.');
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (entry.isSymbolicLink() || entry.name.startsWith('.') || privateName.test(entry.name)) {
      throw new Error('Arquivo privado ou link simbólico em assets: ' + entry.name);
    }
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) await validateAssets(path);
    else if (!entry.isFile()) throw new Error('Tipo de arquivo não permitido em assets: ' + entry.name);
  }
}

export async function buildPages({ source = project, destination = resolve(project, 'dist-pages') } = {}) {
  source = resolve(source);
  destination = resolve(destination);
  if (source === destination) throw new Error('A saída deve ser diferente da pasta de origem.');
  // Validate everything before replacing a previous successful build.
  for (const file of publicEntries.filter(entry => entry !== 'assets')) {
    const info = await lstat(resolve(source, file));
    if (info.isSymbolicLink() || !info.isFile()) throw new Error('Arquivo público inválido: ' + file);
  }
  await validateAssets(resolve(source, 'assets'));
  await rm(destination, { recursive: true, force: true });
  await mkdir(destination, { recursive: true });
  for (const entry of publicEntries) await cp(resolve(source, entry), resolve(destination, entry), { recursive: true });
  // Keep GitHub from applying Jekyll processing to the original frontend.
  await writeFile(resolve(destination, '.nojekyll'), '');
  return destination;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  console.log('GitHub Pages: ' + await buildPages());
}
