# Samir Gedeon Machado — Portfólio

Portfólio em HTML, CSS e JavaScript, sem pacotes npm ou serviços externos em produção. O site combina temas claro e escuro, tradução local para português, espanhol e inglês, tipografia Archivo hospedada localmente e interações acessíveis.

## Executar no computador

Extraia a pasta inteira do ZIP. Abra o terminal **na pasta que contém package.json**, com Node.js 20 ou superior instalado:

```sh
npm run dev
```

Mantenha o terminal aberto e acesse http://127.0.0.1:3000 no mesmo computador. Não precisa executar npm install. Também é possível abrir index.html diretamente com a pasta assets e os arquivos CSS/JS preservados.

```sh
npm run check
npm test
npm run build
npm start
```

O build estático fica em dist. O mesmo comando também gera um Worker ESM em dist/server/index.js, que serve esses arquivos na hospedagem com cabeçalhos de segurança, sem dependências extras. npm test gera o build e roda os testes lógicos, HTTP e do Worker. npm start serve o build local. O servidor local não é uma URL de acesso ao ambiente remoto.

## O que foi implementado

- Foto enviada por Samir, com fundo removido e camada artística derivada, alinhada com o retrato natural. No computador, o rosto responde ao movimento do mouse sem precisar clicar: esquerda revela design e direita revela código. Nos extremos, o conteúdo oposto desaparece: design mostra curva Bézier, controles e amostras de cor; código mostra conexões e um fragmento de JavaScript decorativo. O centro restaura os dois lados. A linha e o puxador sobre o rosto foram retirados; o controle continua funcionando por arraste, botões de seleção, toque e setas do teclado. Os recortes têm transparência e foram otimizados em WebP.
- Tema claro em creme e preto, com uma nova textura original de papel fino, seguindo a cor, a escala e a intensidade de granulação conferidas na referência; tema escuro em preto, azul e lavanda. O botão do cabeçalho troca o tema e informa o modo que será ativado.
- Seletor de idioma junto ao tema, com bandeiras SVG do Brasil, da Espanha e dos Estados Unidos. Português é o padrão, e a escolha é salva no navegador. O seletor funciona com teclado, Escape e clique fora; as traduções incluem textos, acessibilidade e estados dinâmicos, preservando filtros, abas e seleções. O currículo continua em PT-BR e é identificado assim nas versões ES/EN; o inglês básico do perfil é mantido.
- Sem uma escolha salva, a primeira visita acompanha a preferência de cores do sistema. A escolha explícita é preservada no navegador e prevalece sobre mudanças posteriores do sistema. Se o armazenamento estiver indisponível, a troca continua funcionando durante a visita.
- Rolagem nativa com entradas de conteúdo mais expressivas e sequenciadas. Links, projetos e peças respondem ao hover e ao foco; as transições são finitas e não bloqueiam a leitura.
- Editor amplo em tons neutros, com barra de atividades, explorador funcional, currículo, abas superiores, breadcrumb, numeração de linhas e realce de sintaxe. Ícones oficiais Material Icon Theme de Markdown, JSON, JavaScript e PDF correspondem aos arquivos, com SVGs e licença MIT locais em assets/icons; origem em docs/icones.md. Cada aba pode ser fechada pelo botão × ou Delete; setas, Home e End navegam entre as abertas. O explorador e o menu Arquivos reabrem os arquivos, inclusive no celular. Ao fechar todas, aparece um estado vazio com atalhos úteis. Escape fecha o menu.
- Currículo factual em PDF, de uma página, com texto selecionável e links reais.
- Oito tecnologias com logos oficiais em uma bancada com profundidade CSS 3D, rotação ligada à rolagem e parallax curto do mouse. Uma conexão luminosa liga a peça selecionada ao núcleo, que mostra seu nome; a peça ativa se eleva e o painel muda com uma transição curta. A flutuação discreta só ocorre enquanto a bancada está visível. Cada peça mantém explicação e projeto relacionado.
- Fluido real em WebGL no contato: vorticidade, pressão e mistura de pigmentos em alta resolução, com a configuração da referência. O motor MIT de Pavel Dobryakov foi adaptado e sua licença está em assets/vendor/fluid-LICENSE.txt. Cores HSV com densidade baixa e composição transparente produzem os gradientes; não há faixas vetoriais. O efeito mantém uma cauda de vários segundos, com dissipação e encerramento, e protege os textos. A seta de contato usa SVG para manter o desenho nítido.
- Preferência do sistema de movimento reduzido e controle persistente. O modo reduzido interrompe o acompanhamento automático do retrato, as entradas de rolagem, o movimento da bancada e o rastro colorido; o retrato continua operável pelos controles manuais. Dispositivos leves e celulares usam a cena estática e não desenham o rastro.
- Quatro projetos confirmados, filtros e ampliação das capturas com diálogo nativo e restauração do foco.
- Conteúdo, projetos, contatos e currículo permanecem acessíveis sem JavaScript.

## Conteúdo confirmado

Drew Studio, Controle de estoque, Fruta e Catálogo de jogos em Django. As capturas vêm dos próprios repositórios; o trecho de Python é real. Nenhuma demo externa não confirmada foi adicionada. O catálogo usa JsonResponse; Django REST e MySQL são apresentados como estudos, sem atribuí-los indevidamente à implementação dos projetos.

Formação, estágio, objetivo profissional e inglês básico foram fornecidos por Samir. A foto atual foi enviada por Samir nesta conversa. Os contatos foram confirmados no perfil público https://github.com/SamirGedeon. Evidências em docs/projects.json e texto do currículo em docs/curriculo.md.

A direção combina princípios das referências fornecidas sem reutilizar seus layouts, código, textos ou imagens. Archivo e as demais fontes possuem licenças OFL em assets/fonts.

## Validação

Verificações estáticas de sintaxe, IDs, assets, âncoras e ARIA; testes de lógica com DOM emulado; testes de integração e ciclo de vida do fluido com motor simulado; testes HTTP dos modos dev/dist, incluindo os arquivos reais e bloqueio de caminhos privados. Esses testes verificam lógica e respostas HTTP, sem validar renderização, composição, layout ou eventos nativos do navegador.

Nesta rodada não foi executado navegador, pois as ferramentas de prévia/CUA estavam indisponíveis. A simulação e seus shaders também foram executados em OpenGL ES nativo, com compilação, framebuffers, composição e imagens reais. O escopo atual de localização e textura está em docs/verification-v9.md e docs/paper-v9.md. A validação gráfica anterior do motor está em docs/verification-v8.md, e sua origem/API estão em docs/fluid-source.md. As baterias de Chromium e capturas descritas em docs/verification-v4.md, docs/verification-v3.md e docs/verification-v2.md pertencem às versões anteriores e não validam visualmente esta atualização.

A fonte, o PDF e o ZIP são arquivos locais servidos pelo site. A saída estática para GitHub Pages pode ser publicada diretamente, com todos os recursos locais preservados. O pacote completo de desenvolvimento continua disponível no download de código.

### Repetir a verificação no navegador

Opcional: com o servidor local ligado e um Chromium separado iniciado com depuração local na porta 9223, execute `npm run test:browser`. O teste usa http://127.0.0.1:3000 por padrão; CDP_URL e PORTFOLIO_URL permitem selecionar outro endpoint local. Ele guarda capturas e downloads apenas em work/browser-qa. Não é necessário para visitar o portfólio.

### Repetir a validação nativa dos shaders

Opcional, apenas em Linux com Python 3, libEGL/Mesa e suporte a EGL surfaceless: execute `npm run test:gpu`. O teste grava chamadas reais do motor e as reproduz em OpenGL ES, conferindo shaders, framebuffers, pigmento, máscara, fade e limpeza. Não usa navegador nem servidor. Salva os resultados apenas em work/gpu-qa. A variante GLSL 1 usa a equivalência dos formatos half-float no contexto GLES 3; esse teste não representa um navegador WebGL 1. Isso não é necessário para abrir ou rodar o site no Windows.

## Compartilhamento e segurança

O endereço de publicação configurado neste código é https://samirgedeon.github.io/, no repositório público https://github.com/SamirGedeon/SamirGedeon.github.io. A disponibilidade depende da publicação do GitHub Pages, que deve ser conferida em Settings → Pages. Os metadados apontam para esse endereço. O link do perfil GitHub só deve ser trocado depois de verificar a publicação.

Metadados Open Graph e uma imagem de 1200 × 630 estão incluídos para as prévias de compartilhamento. Políticas de segurança, limites e cuidados com credenciais estão em SECURITY.md. A hospedagem atual usa um Worker que aplica cabeçalhos diretamente nas respostas; dist/_headers também fica disponível para outras hospedagens estáticas compatíveis. O pacote de publicação do Sites contém apenas .openai/hosting.json e dist/server, preservando o project_id existente.

### Publicar no GitHub Pages

1. Crie um repositório público chamado exatamente `SamirGedeon.github.io` na conta `SamirGedeon`. Esse nome produz o endereço da página pessoal sem um sufixo de projeto.
2. Execute `npm run build:pages`. A saída em `dist-pages` contém apenas `index.html`, `styles.css`, `app.js`, `assets` e `.nojekyll`. O Worker, os scripts de desenvolvimento e as configurações internas não fazem parte dessa saída.
3. Envie o **conteúdo** de `dist-pages` para a raiz da branch `main` do repositório. Se usar o ZIP de publicação, extraia-o primeiro: não envie apenas o ZIP ao GitHub. O arquivo `index.html` deve ficar na raiz.
4. No repositório, acesse **Settings → Pages → Build and deployment → Deploy from a branch**. Selecione **main / (root)** e salve. Ative **Enforce HTTPS** quando disponível.
5. Aguarde a publicação do GitHub e confira a página, as imagens, o currículo e o ZIP antes de trocar o endereço no perfil e no LinkedIn.

GitHub Pages serve arquivos estáticos e não executa `worker/index.js` nem interpreta `_headers`. A CSP e a política de referência no HTML continuam ativas; os cabeçalhos personalizados do Worker não são transferidos para o Pages. A saída estática não inclui credenciais nem uma API de escrita.

Para gerar novamente o ZIP de código, use `python3 scripts/package-source.py` (ou `py scripts/package-source.py` no Windows com Python instalado). O empacotador valida os caminhos antes de substituir o arquivo de download. Isso não é necessário para executar o portfólio.
